import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import {
  Database, Users, Utensils, Activity, TrendingUp, PlusCircle,
  Settings, LogOut, Shield, Terminal, Download, Upload, Trash2,
  Edit3, Check, X, Search, Star, Sparkles, Server, Code, Layers,
  RefreshCw, Lock, UserPlus, Key, FileSpreadsheet, Camera, Play, Copy
} from 'lucide-react';
import { initializeApp } from 'firebase/app';
import {
  getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged
} from 'firebase/auth';
import {
  getFirestore, doc, setDoc, deleteDoc, onSnapshot, collection
} from 'firebase/firestore';

/* ============================================================================
   1. FIREBASE CLOUD & LITEDB ENGINE INITIALIZATION
   ============================================================================ */
let fbApp = null;
let auth = null;
let db = null;
const appId = typeof __app_id !== 'undefined' ? __app_id : 'longevity-cockpit-pro';

try {
  if (typeof __firebase_config !== 'undefined' && __firebase_config) {
    const firebaseConfig = JSON.parse(__firebase_config);
    fbApp = initializeApp(firebaseConfig);
    auth = getAuth(fbApp);
    db = getFirestore(fbApp);
  }
} catch (e) {
  console.warn('Startet im lokalen In-Memory LiteDB-Modus:', e);
}

/* ============================================================================
   2. FORMATIERUNG, MATHEMATIK & KRYPTO-HELFER
   ============================================================================ */
const nf0 = new Intl.NumberFormat('de-DE', { maximumFractionDigits: 0 });
const nf1 = new Intl.NumberFormat('de-DE', { minimumFractionDigits: 1, maximumFractionDigits: 1 });
const nf2 = new Intl.NumberFormat('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseDate = (s) => new Date(`${s}T12:00:00`);
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const diffDays = (a, b) => Math.round((b - a) / 86400000);
const todayStr = () => ymd(new Date());
const fmtDM = (s) => { if (!s) return ''; const d = parseDate(s); return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.`; };
const fmtWD = (s) => { if (!s) return ''; return parseDate(s).toLocaleDateString('de-DE', { weekday: 'short', day: '2-digit', month: '2-digit' }); };
const num = (v) => (typeof v === 'number' && isFinite(v)) ? v : null;
const sgn = (v, f = nf1) => (v > 0 ? '+' : v < 0 ? '−' : '') + f.format(Math.abs(v));
const avg = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : null);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

async function hashPassword(pw) {
  const enc = new TextEncoder().encode('longevity_salt_v1_' + String(pw));
  const buf = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Vorberechneter SHA-256 Hash für Standard-Passwort "1234"
const DEFAULT_PW_HASH_1234 = '1b87d8a7e53f2f3b58c866971c1b8609c726430187250a69535437c667b14d9f';

/* ============================================================================
   3. DATENBANK-SCHEMA & INITIALE SEED-DATEN (SHARED & DEMO-USER)
   ============================================================================ */
const DB_SCHEMA = {
  app_users: {
    pk: 'username',
    scope: 'GLOBAL (Auth & User-Config)',
    description: 'Benutzerkonten, Passwort-Hashes, Rollen (admin/member), persönliche Ziele (cfg) & Präferenzen (prefs)',
    columns: ['username', 'displayName', 'role', 'passwordHash', 'cfg', 'prefs', 'createdAt']
  },
  shared_articles: {
    pk: 'id',
    scope: 'SHARED (Alle Benutzer)',
    description: 'Gemeinsame Lebensmittel-, Snack- & Rezeptdatenbank für alle Benutzer und den Snack-O-Mat',
    columns: ['id', 'n', 'p', 'k', 'pr', 'carbs', 'fat', 'fiber', 'cat', 'gut', 'est', 'author', 'updatedAt']
  },
  user_weights: {
    pk: 'id',
    scope: 'USER-ISOLATED (je Benutzer)',
    description: 'Tägliche Gewichtsmessungen pro Benutzer (Schlüssel: username__YYYY-MM-DD)',
    columns: ['id', 'username', 'date', 'weight', 'updatedAt']
  },
  user_days: {
    pk: 'id',
    scope: 'USER-ISOLATED (je Benutzer)',
    description: 'Tageswerte (Kalorien, Makros, Ballaststoffe, Schritte, Krafttraining & gebuchte Artikel) je Benutzer',
    columns: ['id', 'username', 'date', 'kcal', 'protein', 'carbs', 'fat', 'fiber', 'steps', 'trained', 'bookedArticles', 'updatedAt']
  }
};

const DEFAULT_CFG = {
  startDate: ymd(addDays(new Date(), -21)),
  startWeight: 92.9,
  etappe: 85.0,
  goal: 80.0,
  kcal: 1788,
  proteinMin: 120,
  proteinMax: 135,
  fiber: 40,
  steps: 10000
};

const DEFAULT_PREFS = {
  theme: 'system',
  curfew: 20,
  corridor: '0.4-0.7',
  favorites: ['art-2', 'art-5', 'art-6']
};

const INITIAL_ARTICLES = [
  { id: 'art-1', n: 'Grieß Quark, 250 g', p: 'Pur oder mit einem Löffel Beeren', k: 158, pr: 16.3, carbs: 14, fat: 3, fiber: 1.5, est: false, cat: 'saver', gut: '', author: 'System', updatedAt: '2026-10-01' },
  { id: 'art-2', n: 'Magerquark mit Beeren', p: '250 g Magerquark, 50 g Himbeeren', k: 190, pr: 31, carbs: 13, fat: 1, fiber: 3.5, est: true, cat: 'saver', gut: 'Polyphenole', author: 'System', updatedAt: '2026-10-01' },
  { id: 'art-3', n: 'Vanilla-Erdnuss-Fluff', p: '250 g Magerquark, 3 g More Chunky Vanilla Perfection, 10 g Crunchy Erdnussbutter, 30 g Himbeeren', k: 255, pr: 33, carbs: 14, fat: 6, fiber: 3, est: true, cat: 'upgrade', gut: '', author: 'System', updatedAt: '2026-10-01' },
  { id: 'art-4', n: 'Harzer pur', p: '100 g Harzer Käse mit Zwiebelringen und Pfeffer', k: 125, pr: 30, carbs: 0.5, fat: 0.5, fiber: 0.5, est: true, cat: 'saver', gut: '', author: 'System', updatedAt: '2026-10-01' },
  { id: 'art-5', n: 'Harzer auf Sauerteig', p: '100 g Harzer Käse auf 1 Scheibe Roggen-Mischbrot (50 g), Zwiebel, Gurke', k: 240, pr: 34, carbs: 22, fat: 1.5, fiber: 4, est: true, cat: 'saver', gut: 'Sauerteig', author: 'System', updatedAt: '2026-10-01' },
  { id: 'art-6', n: 'Hähnchen mit Sauerkraut', p: '150 g mageres Hähnchen, 100 g Sauerkraut, Senf', k: 175, pr: 35, carbs: 2, fat: 2.5, fiber: 2.5, est: true, cat: 'saver', gut: 'Fermentiert', author: 'System', updatedAt: '2026-10-01' },
  { id: 'art-7', n: 'Skyr mit Kürbiskernen', p: '200 g Skyr, 10 g Kürbiskerne, Zimt', k: 186, pr: 27, carbs: 8, fat: 5, fiber: 1, est: true, cat: 'upgrade', gut: 'Zink', author: 'System', updatedAt: '2026-10-01' },
  { id: 'art-8', n: 'Skyr mit amtlichem Löffel', p: '150 g Skyr, 20 g Erdnussmus (der amtliche Löffel)', k: 220, pr: 23, carbs: 8, fat: 10, fiber: 2, est: true, cat: 'upgrade', gut: '', author: 'System', updatedAt: '2026-10-01' },
  { id: 'art-9', n: 'Lachs-Hummus-Brot', p: '60 g Stremel-Lachs (Pfeffer) auf 1 Scheibe Sauerteig (50 g) mit 20 g Hummus', k: 250, pr: 19, carbs: 23, fat: 9, fiber: 4, est: true, cat: 'upgrade', gut: 'Omega-3', author: 'System', updatedAt: '2026-10-01' },
  { id: 'art-10', n: 'Ei-Serrano-Brot', p: '2 Eier, 20 g Serrano Schinken auf 1 Scheibe Sauerteig (50 g)', k: 300, pr: 22, carbs: 22, fat: 13, fiber: 3, est: true, cat: 'upgrade', gut: '', author: 'System', updatedAt: '2026-10-01' },
  { id: 'art-11', n: 'Kefir Hafer Apfel Quark, halbe Portion', p: 'Dein Rezept, halbe Portion', k: 242, pr: 22, carbs: 28, fat: 4, fiber: 4.5, est: false, cat: 'upgrade', gut: 'Fermentiert, Haferflocken', author: 'System', updatedAt: '2026-10-01' },
  { id: 'art-12', n: 'Loaded Dal Bowl', p: '400 g Dal ohne Kokos, 1 Ei, 1 TL Crispy Chili in Oil, 50 g Skyr als Dip', k: 420, pr: 32, carbs: 45, fat: 11, fiber: 12, est: true, cat: 'meal', gut: 'Hülsenfrüchte', author: 'System', updatedAt: '2026-10-01' }
];

function buildInitialDemoData() {
  const users = {};
  const weights = {};
  const days = {};
  const articles = {};

  INITIAL_ARTICLES.forEach((a) => { articles[a.id] = a; });

  // 1. Admin User: Nadine (Passwort: 1234)
  const startD = ymd(addDays(new Date(), -21));
  users['nadine'] = {
    username: 'nadine',
    displayName: 'Nadine (Admin)',
    role: 'admin',
    passwordHash: DEFAULT_PW_HASH_1234,
    createdAt: startD,
    cfg: { ...DEFAULT_CFG, startDate: startD },
    prefs: { ...DEFAULT_PREFS }
  };

  // 2. Zweiter User: Alex (Passwort: 1234)
  users['alex'] = {
    username: 'alex',
    displayName: 'Alex',
    role: 'member',
    passwordHash: DEFAULT_PW_HASH_1234,
    createdAt: startD,
    cfg: {
      startDate: startD,
      startWeight: 88.5,
      etappe: 83.0,
      goal: 78.0,
      kcal: 2150,
      proteinMin: 140,
      proteinMax: 165,
      fiber: 38,
      steps: 11000
    },
    prefs: {
      theme: 'system',
      curfew: 21,
      corridor: '0.4-0.7',
      favorites: ['art-6', 'art-12']
    }
  };

  // Realistische 21-Tage Historie für Nadine generieren
  let curW = 92.9;
  for (let i = 21; i >= 0; i--) {
    const ds = ymd(addDays(new Date(), -i));
    const noise = (Math.sin(i * 1.3) * 0.25);
    curW = Math.round((92.9 - ((21 - i) * 0.085) + noise) * 10) / 10;
    const wId = `nadine__${ds}`;
    weights[wId] = { id: wId, username: 'nadine', date: ds, weight: curW, updatedAt: ds };

    if (i > 0) {
      const dId = `nadine__${ds}`;
      days[dId] = {
        id: dId,
        username: 'nadine',
        date: ds,
        kcal: 1680 + ((i * 37) % 160),
        protein: 122 + ((i * 11) % 18),
        carbs: 135 + ((i * 19) % 30),
        fat: 54 + ((i * 7) % 14),
        fiber: 36 + ((i * 5) % 9),
        steps: 9600 + ((i * 650) % 2800),
        trained: i % 2 === 0,
        bookedArticles: [],
        updatedAt: ds
      };
    } else {
      // Heute (laufender Tag)
      const dId = `nadine__${ds}`;
      days[dId] = {
        id: dId,
        username: 'nadine',
        date: ds,
        kcal: 1240,
        protein: 94,
        carbs: 105,
        fat: 42,
        fiber: 29,
        steps: 8450,
        trained: true,
        bookedArticles: [
          { id: 'art-2', name: 'Magerquark mit Beeren', mult: 1, kcal: 190, protein: 31, carbs: 13, fat: 1, fiber: 3.5, ts: Date.now() - 3600000 }
        ],
        updatedAt: ds
      };
    }
  }

  // Kurze Historie für Alex
  for (let i = 14; i >= 0; i--) {
    const ds = ymd(addDays(new Date(), -i));
    const wId = `alex__${ds}`;
    weights[wId] = {
      id: wId,
      username: 'alex',
      date: ds,
      weight: Math.round((88.5 - (14 - i) * 0.07 + Math.cos(i) * 0.2) * 10) / 10,
      updatedAt: ds
    };
    if (i > 0) {
      const dId = `alex__${ds}`;
      days[dId] = {
        id: dId,
        username: 'alex',
        date: ds,
        kcal: 2080 + ((i * 40) % 140),
        protein: 148 + ((i * 9) % 16),
        carbs: 190,
        fat: 68,
        fiber: 37,
        steps: 10800,
        trained: i % 3 === 0,
        bookedArticles: [],
        updatedAt: ds
      };
    }
  }

  return { users, articles, weights, days };
}

/* ============================================================================
   4. MINI-SQL / LITEDB QUERY-ENGINE FÜR DEN DB-ADMINISTRATOR
   ============================================================================ */
function executeLiteSQL(queryStr, dbTables) {
  const q = (queryStr || '').trim();
  const m = /^SELECT\s+(.+?)\s+FROM\s+([a-zA-Z0-9_]+)(?:\s+WHERE\s+(.+?))?(?:\s+ORDER\s+BY\s+([a-zA-Z0-9_]+)(?:\s+(ASC|DESC))?)?(?:\s+LIMIT\s+(\d+))?;?$/i.exec(q);
  if (!m) {
    throw new Error('Syntax: SELECT * FROM <tabelle> [WHERE feld = wert] [ORDER BY feld ASC|DESC] [LIMIT n]');
  }
  const [, selectCols, tableName, whereClause, orderCol, orderDir, limitStr] = m;
  const tableMap = dbTables[tableName];
  if (!tableMap) {
    throw new Error(`Tabelle "${tableName}" existiert nicht. Verfügbar: ${Object.keys(dbTables).join(', ')}`);
  }

  let rows = Object.values(tableMap);

  // WHERE-Filterung
  if (whereClause) {
    const conds = whereClause.split(/\s+AND\s+/i);
    rows = rows.filter((row) =>
      conds.every((c) => {
        const cm = /^([a-zA-Z0-9_.]+)\s*(=|!=|>=|<=|>|<|LIKE)\s*(.+)$/i.exec(c.trim());
        if (!cm) return true;
        const [, field, op, rawVal] = cm;
        const cleanVal = rawVal.replace(/^['"]|['"]$/g, '');
        const numVal = Number(cleanVal);
        const rVal = field.split('.').reduce((acc, part) => (acc ? acc[part] : undefined), row);

        if (op.toUpperCase() === 'LIKE') {
          const pattern = cleanVal.replace(/%/g, '.*');
          return new RegExp(`^${pattern}$`, 'i').test(String(rVal ?? ''));
        }
        if (!isNaN(numVal) && typeof rVal === 'number') {
          if (op === '=') return rVal === numVal;
          if (op === '!=') return rVal !== numVal;
          if (op === '>') return rVal > numVal;
          if (op === '<') return rVal < numVal;
          if (op === '>=') return rVal >= numVal;
          if (op === '<=') return rVal <= numVal;
        }
        const sVal = String(rVal ?? '');
        if (op === '=') return sVal === cleanVal;
        if (op === '!=') return sVal !== cleanVal;
        return sVal.localeCompare(cleanVal) > 0;
      })
    );
  }

  // ORDER BY
  if (orderCol) {
    const dir = (orderDir || 'ASC').toUpperCase() === 'DESC' ? -1 : 1;
    rows = [...rows].sort((a, b) => {
      const va = a[orderCol];
      const vb = b[orderCol];
      if (typeof va === 'number' && typeof vb === 'number') return (va - vb) * dir;
      return String(va ?? '').localeCompare(String(vb ?? '')) * dir;
    });
  }

  // LIMIT
  if (limitStr) {
    rows = rows.slice(0, Number(limitStr));
  }

  // Projektion (SELECT Spalten)
  if (selectCols.trim() !== '*') {
    const cols = selectCols.split(',').map((s) => s.trim());
    rows = rows.map((r) => {
      const out = {};
      cols.forEach((col) => { out[col] = r[col]; });
      return out;
    });
  }

  return rows;
}

/* Generiert einen vollständigen SQL-Dump (SQLite / Turso / PostgreSQL kompatibel) */
function generateSQLDump(dbTables) {
  const lines = [
    '-- ============================================================================',
    '-- LONGEVITY & ABNEHM-COCKPIT - LIGHTWEIGHT SQLITE / POSTGRESQL DUMP',
    `-- Generated: ${new Date().toISOString()}`,
    '-- ============================================================================',
    '',
    'CREATE TABLE IF NOT EXISTS app_users (',
    '  username TEXT PRIMARY KEY,',
    '  display_name TEXT NOT NULL,',
    '  role TEXT DEFAULT \'member\',',
    '  password_hash TEXT NOT NULL,',
    '  cfg_json TEXT NOT NULL,',
    '  prefs_json TEXT NOT NULL,',
    '  created_at TEXT',
    ');',
    '',
    'CREATE TABLE IF NOT EXISTS shared_articles (',
    '  id TEXT PRIMARY KEY,',
    '  name TEXT NOT NULL,',
    '  parts TEXT,',
    '  kcal REAL NOT NULL,',
    '  protein REAL NOT NULL,',
    '  carbs REAL DEFAULT 0,',
    '  fat REAL DEFAULT 0,',
    '  fiber REAL DEFAULT 0,',
    '  category TEXT DEFAULT \'saver\',',
    '  gut_tag TEXT,',
    '  is_estimated INTEGER DEFAULT 0,',
    '  author TEXT,',
    '  updated_at TEXT',
    ');',
    '',
    'CREATE TABLE IF NOT EXISTS user_weights (',
    '  id TEXT PRIMARY KEY,',
    '  username TEXT NOT NULL,',
    '  date TEXT NOT NULL,',
    '  weight REAL NOT NULL,',
    '  updated_at TEXT',
    ');',
    '',
    'CREATE TABLE IF NOT EXISTS user_days (',
    '  id TEXT PRIMARY KEY,',
    '  username TEXT NOT NULL,',
    '  date TEXT NOT NULL,',
    '  kcal REAL,',
    '  protein REAL,',
    '  carbs REAL,',
    '  fat REAL,',
    '  fiber REAL,',
    '  steps INTEGER,',
    '  trained INTEGER DEFAULT 0,',
    '  booked_articles_json TEXT',
    ');',
    ''
  ];

  const esc = (v) => `'${String(v ?? '').replace(/'/g, "''")}'`;

  Object.values(dbTables.app_users || {}).forEach((u) => {
    lines.push(`INSERT INTO app_users VALUES (${esc(u.username)}, ${esc(u.displayName)}, ${esc(u.role || 'member')}, ${esc(u.passwordHash)}, ${esc(JSON.stringify(u.cfg || {}))}, ${esc(JSON.stringify(u.prefs || {}))}, ${esc(u.createdAt || '')});`);
  });
  lines.push('');

  Object.values(dbTables.shared_articles || {}).forEach((a) => {
    lines.push(`INSERT INTO shared_articles VALUES (${esc(a.id)}, ${esc(a.n)}, ${esc(a.p)}, ${Number(a.k) || 0}, ${Number(a.pr) || 0}, ${Number(a.carbs) || 0}, ${Number(a.fat) || 0}, ${Number(a.fiber) || 0}, ${esc(a.cat || 'saver')}, ${esc(a.gut || '')}, ${a.est ? 1 : 0}, ${esc(a.author || 'System')}, ${esc(a.updatedAt || '')});`);
  });
  lines.push('');

  Object.values(dbTables.user_weights || {}).forEach((w) => {
    lines.push(`INSERT INTO user_weights VALUES (${esc(w.id || `${w.username}__${w.date}`)}, ${esc(w.username)}, ${esc(w.date)}, ${Number(w.weight) || 0}, ${esc(w.updatedAt || '')});`);
  });

  return lines.join('\n');
}

/* ============================================================================
   5. HAUPT-KOMPONENTE: APP
   ============================================================================ */
export default function App() {
  // --- Auth & Cloud Sync State ---
  const [fbUser, setFbUser] = useState(null);
  const [syncMode, setSyncMode] = useState('connecting'); // 'cloud' | 'litedb' | 'connecting'
  const [dbReady, setDbReady] = useState(false);

  // --- LiteDB Tabellen (In-Memory Replikat + Live Cloud Sync) ---
  const initialDemo = useMemo(() => buildInitialDemoData(), []);
  const [usersTable, setUsersTable] = useState(initialDemo.users);
  const [articlesTable, setArticlesTable] = useState(initialDemo.articles);
  const [weightsTable, setWeightsTable] = useState(initialDemo.weights);
  const [daysTable, setDaysTable] = useState(initialDemo.days);
  const [auditLog, setAuditLog] = useState([
    { id: 'log-init', ts: new Date().toLocaleTimeString('de-DE'), action: 'SYSTEM_BOOT', table: 'ALL', key: 'init', actor: 'LiteDB Engine', info: 'Relational-Document Store initialisiert' }
  ]);

  // --- Aktiver Benutzer & Navigation ---
  const [currentUsername, setCurrentUsername] = useState('nadine');
  const [route, setRoute] = useState('heute'); // 'heute' | 'verlauf' | 'eintrag' | 'snack' | 'artikel' | 'konto' | 'dbadmin'
  const [toastMsg, setToastMsg] = useState(null);

  // --- Login / Registrierung State ---
  const [authTab, setAuthTab] = useState('login');
  const [loginUser, setLoginUser] = useState('nadine');
  const [loginPass, setLoginPass] = useState('');
  const [regDisplay, setRegDisplay] = useState('');
  const [regRole, setRegRole] = useState('member');
  const [regStartW, setRegStartW] = useState('90.0');
  const [regGoalW, setRegGoalW] = useState('80.0');
  const [regKcal, setRegKcal] = useState('1800');
  const [regPMin, setRegPMin] = useState('120');
  const [authError, setAuthError] = useState('');

  // --- UI & Sub-View State ---
  const [wRange, setWRange] = useState('90');
  const [editingDate, setEditingDate] = useState(todayStr());
  const [artSearch, setArtSearch] = useState('');
  const [artCatFilter, setArtCatFilter] = useState('all');
  const [artBookDate, setArtBookDate] = useState(todayStr());
  const [articleModalData, setArticleModalData] = useState(null);

  // --- Snack-O-Mat State ---
  const [snMissingP, setSnMissingP] = useState('');
  const [snRestKcal, setSnRestKcal] = useState('');

  // --- DB-Admin Studio State ---
  const [adminActiveTable, setAdminActiveTable] = useState('shared_articles');
  const [adminSearch, setAdminSearch] = useState('');
  const [sqlInput, setSqlInput] = useState('SELECT id, n, k, pr, fiber, cat FROM shared_articles WHERE pr >= 25 ORDER BY k ASC');
  const [sqlResult, setSqlResult] = useState(null);
  const [sqlError, setSqlError] = useState(null);
  const [editingRecordModal, setEditingRecordModal] = useState(null); // { table, id, jsonText, isNew }
  const [showArchModal, setShowArchModal] = useState(false);

  const showToast = useCallback((text) => {
    setToastMsg(text);
  }, []);

  useEffect(() => {
    if (!toastMsg) return;
    const t = setTimeout(() => setToastMsg(null), 2800);
    return () => clearTimeout(t);
  }, [toastMsg]);

  const appendAudit = useCallback((action, table, key, actor, info = '') => {
    setAuditLog((prev) => [
      {
        id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        ts: new Date().toLocaleTimeString('de-DE'),
        action,
        table,
        key,
        actor: actor || 'System',
        info
      },
      ...prev.slice(0, 79)
    ]);
  }, []);

  /* ==========================================================================
     FIREBASE AUTH & REALTIME SNAPSHOT SYNC (RULES 1, 2, 3)
     ========================================================================== */
  useEffect(() => {
    if (!auth || !db) {
      setSyncMode('litedb');
      setDbReady(true);
      return;
    }
    let unsubAuth = () => {};
    const initAuth = async () => {
      try {
        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
          await signInWithCustomToken(auth, __initial_auth_token);
        } else {
          await signInAnonymously(auth);
        }
        unsubAuth = onAuthStateChanged(auth, (u) => {
          setFbUser(u);
        });
      } catch (e) {
        setSyncMode('litedb');
        setDbReady(true);
      }
    };
    initAuth();
    return () => unsubAuth();
  }, []);

  useEffect(() => {
    if (!fbUser || !db) return;

    setSyncMode('cloud');
    const colRef = (name) => collection(db, 'artifacts', appId, 'public', 'data', name);
    const docRef = (name, id) => doc(db, 'artifacts', appId, 'public', 'data', name, id);

    const unsubUsers = onSnapshot(
      colRef('app_users'),
      async (snap) => {
        if (snap.empty) {
          // Seed initial demo users into Cloud DB
          for (const [id, uDoc] of Object.entries(initialDemo.users)) {
            await setDoc(docRef('app_users', id), uDoc);
          }
        } else {
          const m = {};
          snap.docs.forEach((d) => { m[d.id] = d.data(); });
          setUsersTable(m);
        }
        setDbReady(true);
      },
      () => setSyncMode('litedb')
    );

    const unsubArticles = onSnapshot(
      colRef('shared_articles'),
      async (snap) => {
        if (snap.empty) {
          for (const [id, aDoc] of Object.entries(initialDemo.articles)) {
            await setDoc(docRef('shared_articles', id), aDoc);
          }
        } else {
          const m = {};
          snap.docs.forEach((d) => { m[d.id] = d.data(); });
          setArticlesTable(m);
        }
      },
      () => {}
    );

    const unsubWeights = onSnapshot(
      colRef('user_weights'),
      async (snap) => {
        if (snap.empty) {
          for (const [id, wDoc] of Object.entries(initialDemo.weights)) {
            await setDoc(docRef('user_weights', id), wDoc);
          }
        } else {
          const m = {};
          snap.docs.forEach((d) => { m[d.id] = d.data(); });
          setWeightsTable(m);
        }
      },
      () => {}
    );

    const unsubDays = onSnapshot(
      colRef('user_days'),
      async (snap) => {
        if (snap.empty) {
          for (const [id, dDoc] of Object.entries(initialDemo.days)) {
            await setDoc(docRef('user_days', id), dDoc);
          }
        } else {
          const m = {};
          snap.docs.forEach((d) => { m[d.id] = d.data(); });
          setDaysTable(m);
        }
      },
      () => {}
    );

    return () => {
      unsubUsers();
      unsubArticles();
      unsubWeights();
      unsubDays();
    };
  }, [fbUser, initialDemo]);

  /* ==========================================================================
     LITEDB CRUD-TRANSAKTIONEN (CLOUD + LOKALER STATE)
     ========================================================================== */
  const dbUpsert = useCallback(async (tableName, id, record, merge = true) => {
    const actor = currentUsername || 'System';
    // 1. Optimistisches Update im LiteDB State
    const updater = (prev) => ({
      ...prev,
      [id]: merge && prev[id] ? { ...prev[id], ...record } : record
    });

    if (tableName === 'app_users') setUsersTable(updater);
    else if (tableName === 'shared_articles') setArticlesTable(updater);
    else if (tableName === 'user_weights') setWeightsTable(updater);
    else if (tableName === 'user_days') setDaysTable(updater);

    appendAudit(merge ? 'UPDATE' : 'INSERT', tableName, id, actor, JSON.stringify(record).slice(0, 70));

    // 2. Persistenz in Cloud Firestore (falls verbunden)
    if (syncMode === 'cloud' && fbUser && db) {
      const ref = doc(db, 'artifacts', appId, 'public', 'data', tableName, id);
      await setDoc(ref, record, { merge });
    }
  }, [currentUsername, syncMode, fbUser, appendAudit]);

  const dbDelete = useCallback(async (tableName, id) => {
    const actor = currentUsername || 'System';
    const remover = (prev) => {
      const next = { ...prev };
      delete next[id];
      return next;
    };

    if (tableName === 'app_users') setUsersTable(remover);
    else if (tableName === 'shared_articles') setArticlesTable(remover);
    else if (tableName === 'user_weights') setWeightsTable(remover);
    else if (tableName === 'user_days') setDaysTable(remover);

    appendAudit('DELETE', tableName, id, actor, 'Datensatz gelöscht');

    if (syncMode === 'cloud' && fbUser && db) {
      const ref = doc(db, 'artifacts', appId, 'public', 'data', tableName, id);
      await deleteDoc(ref);
    }
  }, [currentUsername, syncMode, fbUser, appendAudit]);

  /* ==========================================================================
     AKTIVER BENUTZER & ABGELEITETE DATEN-SLICES
     ========================================================================== */
  const currentUser = currentUsername ? usersTable[currentUsername] : null;
  const activeCfg = useMemo(() => ({ ...DEFAULT_CFG, ...(currentUser?.cfg || {}) }), [currentUser]);
  const activePrefs = useMemo(() => ({ ...DEFAULT_PREFS, ...(currentUser?.prefs || {}) }), [currentUser]);

  // Theme anwenden
  useEffect(() => {
    const root = document.documentElement;
    if (activePrefs.theme === 'light' || activePrefs.theme === 'dark') {
      root.setAttribute('data-theme', activePrefs.theme);
    } else {
      root.removeAttribute('data-theme');
    }
  }, [activePrefs.theme]);

  // Isolierte Gewichte des aktuellen Benutzers
  const userWeights = useMemo(() => {
    if (!currentUsername) return {};
    const m = {};
    Object.values(weightsTable).forEach((w) => {
      if (w && w.username === currentUsername && w.date) {
        m[w.date] = w;
      }
    });
    return m;
  }, [weightsTable, currentUsername]);

  // Isolierte Tage des aktuellen Benutzers
  const userDays = useMemo(() => {
    if (!currentUsername) return {};
    const m = {};
    Object.values(daysTable).forEach((d) => {
      if (d && d.username === currentUsername && d.date) {
        m[d.date] = d;
      }
    });
    return m;
  }, [daysTable, currentUsername]);

  // Libra-glättende Gewichtsreihe
  const weightSeries = useMemo(() => {
    const arr = Object.values(userWeights)
      .filter((x) => x && num(x.weight) !== null && x.date)
      .sort((a, b) => (a.date < b.date ? -1 : 1));
    let t = null;
    let prev = null;
    return arr.map((x) => {
      const d = parseDate(x.date);
      if (t === null) t = x.weight;
      else {
        const g = Math.max(1, diffDays(prev, d));
        t = t + (1 - Math.pow(0.85, g)) * (x.weight - t);
      }
      prev = d;
      return { date: x.date, d, w: x.weight, t };
    });
  }, [userWeights]);

  const calcTrendAt = useCallback((ser, d) => {
    if (!ser.length) return null;
    if (d <= ser[0].d) return ser[0].t;
    for (let i = ser.length - 1; i > 0; i--) {
      if (ser[i - 1].d <= d) {
        const a = ser[i - 1];
        const b = ser[i];
        const span = diffDays(a.d, b.d) || 1;
        return a.t + (b.t - a.t) * (diffDays(a.d, d) / span);
      }
    }
    return ser[0].t;
  }, []);

  const calcTempo = useCallback((ser, days) => {
    if (ser.length < 2) return null;
    const last = ser[ser.length - 1];
    const from = addDays(last.d, -days);
    if (ser[0].d > from) return null;
    return ((calcTrendAt(ser, from) - last.t) / days) * 7;
  }, [calcTrendAt]);

  // 7-Tage "Big Rocks" Schnitt bis gestern
  const rollingStats = useMemo(() => {
    const today = todayStr();
    const dates = Object.keys(userDays).filter((k) => k < today).sort().slice(-7);
    const rows = dates.map((k) => userDays[k]);
    const col = (key) => rows.map((r) => num(r[key])).filter((v) => v !== null);
    const weekFrom = ymd(addDays(new Date(), -6));
    const trained = Object.keys(userDays).filter((k) => k >= weekFrom && k <= today && userDays[k].trained).length;
    return {
      n: rows.length,
      kcal: avg(col('kcal')), kcalN: col('kcal').length,
      protein: avg(col('protein')), proteinN: col('protein').length,
      fiber: avg(col('fiber')), fiberN: col('fiber').length,
      steps: avg(col('steps')), stepsN: col('steps').length,
      trained
    };
  }, [userDays]);

  /* ==========================================================================
     AUTHENTIFIZIERUNG HANDLER
     ========================================================================== */
  const handleAuthSubmit = async (e) => {
    e.preventDefault();
    setAuthError('');
    const cleanUser = (loginUser || '').trim().toLowerCase().replace(/[^a-z0-9_-]/g, '');
    if (cleanUser.length < 2) {
      setAuthError('Bitte gültigen Benutzernamen (mind. 2 Zeichen) eingeben.');
      return;
    }
    if ((loginPass || '').length < 4) {
      setAuthError('Passwort muss mindestens 4 Zeichen lang sein.');
      return;
    }

    const pwHash = loginPass === '1234' ? DEFAULT_PW_HASH_1234 : await hashPassword(loginPass);
    const existing = usersTable[cleanUser];

    if (authTab === 'login') {
      if (!existing) {
        setAuthError('Benutzer nicht gefunden. Bitte registrieren.');
        return;
      }
      if (existing.passwordHash !== pwHash) {
        setAuthError('Passwort ist nicht korrekt (Tipp für Demo-Profile: 1234).');
        return;
      }
      setCurrentUsername(cleanUser);
      setLoginPass('');
      appendAudit('LOGIN', 'app_users', cleanUser, cleanUser, 'Erfolgreiche Anmeldung');
      showToast(`Angemeldet als ${existing.displayName || cleanUser}`);
    } else {
      if (existing) {
        setAuthError('Benutzername bereits vergeben.');
        return;
      }
      const startW = Number(String(regStartW).replace(',', '.')) || 90;
      const goalW = Number(String(regGoalW).replace(',', '.')) || 80;
      const pMin = Number(regPMin) || 120;
      const newUserObj = {
        username: cleanUser,
        displayName: (regDisplay || '').trim() || cleanUser,
        role: regRole,
        passwordHash: pwHash,
        createdAt: todayStr(),
        cfg: {
          ...DEFAULT_CFG,
          startDate: todayStr(),
          startWeight: startW,
          etappe: Math.round(((startW + goalW) / 2) * 10) / 10,
          goal: goalW,
          kcal: Number(regKcal) || 1800,
          proteinMin: pMin,
          proteinMax: pMin + 15
        },
        prefs: { ...DEFAULT_PREFS }
      };
      await dbUpsert('app_users', cleanUser, newUserObj, false);
      setCurrentUsername(cleanUser);
      setLoginPass('');
      showToast(`Konto ${newUserObj.displayName} angelegt!`);
    }
  };

  /* ==========================================================================
     ARTIKEL-BUCHUNG & FAVORITEN
     ========================================================================== */
  const bookArticle = async (artId, mult = 1, targetDateOverride = null) => {
    if (!currentUsername) return;
    const art = articlesTable[artId];
    if (!art) return;
    const ds = targetDateOverride || (route === 'artikel' ? artBookDate : todayStr());
    const docId = `${currentUsername}__${ds}`;
    const ex = userDays[ds] || {
      id: docId,
      username: currentUsername,
      date: ds,
      kcal: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      fiber: 0,
      steps: null,
      trained: false,
      bookedArticles: []
    };

    const addK = Math.round((num(art.k) || 0) * mult);
    const addP = Math.round((num(art.pr) || 0) * mult * 10) / 10;
    const addC = Math.round((num(art.carbs) || 0) * mult * 10) / 10;
    const addF = Math.round((num(art.fat) || 0) * mult * 10) / 10;
    const addFb = Math.round((num(art.fiber) || 0) * mult * 10) / 10;

    const updated = {
      ...ex,
      id: docId,
      username: currentUsername,
      date: ds,
      kcal: Math.round((num(ex.kcal) || 0) + addK),
      protein: Math.round(((num(ex.protein) || 0) + addP) * 10) / 10,
      carbs: Math.round(((num(ex.carbs) || 0) + addC) * 10) / 10,
      fat: Math.round(((num(ex.fat) || 0) + addF) * 10) / 10,
      fiber: Math.round(((num(ex.fiber) || 0) + addFb) * 10) / 10,
      bookedArticles: [
        ...(Array.isArray(ex.bookedArticles) ? ex.bookedArticles : []),
        { id: art.id, name: art.n, mult, kcal: addK, protein: addP, carbs: addC, fat: addF, fiber: addFb, ts: Date.now() }
      ],
      updatedAt: todayStr()
    };

    await dbUpsert('user_days', docId, updated, false);
    showToast(`${mult !== 1 ? nf1.format(mult) + '× ' : ''}${art.n} auf ${fmtDM(ds)} gebucht (+${addK} kcal)`);
  };

  const toggleFavorite = async (artId) => {
    if (!currentUser) return;
    const favs = new Set(activePrefs.favorites || []);
    if (favs.has(artId)) favs.delete(artId);
    else favs.add(artId);
    const nextPrefs = { ...activePrefs, favorites: Array.from(favs) };
    await dbUpsert('app_users', currentUsername, { prefs: nextPrefs }, true);
  };

  /* ==========================================================================
     STYLESHEET INJECTION (Original Design Tokens + DB-Admin Studio Styling)
     ========================================================================== */
  const customStyles = `
    @import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700;12..96,800&family=DM+Sans:opsz,wght@9..40,400;9..40,500;9..40,700&family=JetBrains+Mono:wght@400;600&display=swap');

    :root {
      color-scheme: light;
      --bg: #EDF1EE; --surface: #FFFFFF; --surface2: #F3F6F4; --ink: #12201B; --muted: #58695F; --line: #D3DDD7;
      --accent: #0C6B58; --accent-ink: #FFFFFF;
      --hero-bg: #0F3D33; --hero-ink: #EAF6F1; --hero-muted: #9CC2B6; --hero-track: #1F5A4C; --hero-fill: #7FE0C3; --hero-line: #2A6656;
      --kcal: #B8730A; --protein: #A93A66; --fiber: #3F8A2F; --steps: #2F6FB5; --over: #7D8B84;
      --ok: #1F7A4D; --warn: #9A5B00; --gap: #B3402A;
      --f-display: "Bricolage Grotesque", ui-sans-serif, system-ui, sans-serif;
      --f-body: "DM Sans", ui-sans-serif, system-ui, sans-serif;
      --f-mono: "JetBrains Mono", ui-monospace, SFMono-Regular, monospace;
      --r: 14px;
    }
    @media (prefers-color-scheme: dark) {
      :root:not([data-theme="light"]) {
        --bg: #0C1411; --surface: #131D19; --surface2: #1A2621; --ink: #E7F0EB; --muted: #93A59C; --line: #273832;
        --accent: #4CC3A5; --accent-ink: #06231C;
        --hero-bg: #123A31; --hero-ink: #EAF6F1; --hero-muted: #93BBAE; --hero-track: #1F5A4C; --hero-fill: #7FE0C3; --hero-line: #2A6656;
        --kcal: #E3A33A; --protein: #E27DA3; --fiber: #7FC46B; --steps: #6FA8E8; --over: #7D8B84;
        --ok: #5FD39A; --warn: #E3A33A; --gap: #F08A72;
        color-scheme: dark;
      }
    }
    :root[data-theme="dark"] {
      --bg: #0C1411; --surface: #131D19; --surface2: #1A2621; --ink: #E7F0EB; --muted: #93A59C; --line: #273832;
      --accent: #4CC3A5; --accent-ink: #06231C;
      --hero-bg: #123A31; --hero-ink: #EAF6F1; --hero-muted: #93BBAE; --hero-track: #1F5A4C; --hero-fill: #7FE0C3; --hero-line: #2A6656;
      --kcal: #E3A33A; --protein: #E27DA3; --fiber: #7FC46B; --steps: #6FA8E8; --over: #7D8B84;
      --ok: #5FD39A; --warn: #E3A33A; --gap: #F08A72;
      color-scheme: dark;
    }
    body {
      background: var(--bg); color: var(--ink); font-family: var(--f-body);
      font-size: 15px; line-height: 1.45; margin: 0;
    }
    h1, h2, h3, .font-display { font-family: var(--f-display); letter-spacing: -0.01em; }
    .font-mono-code { font-family: var(--f-mono); }
    .num { font-variant-numeric: tabular-nums; }
    .cockpit-card {
      background: var(--surface); border: 1px solid var(--line);
      border-radius: var(--r); padding: 16px;
    }
    .cockpit-input {
      width: 100%; height: 42px; border: 1px solid var(--line);
      background: var(--surface2); border-radius: 10px; padding: 0 12px;
      font-size: 15px; color: var(--ink);
    }
    .cockpit-input:focus {
      outline: 2px solid var(--accent); outline-offset: 1px; background: var(--surface);
    }
    .cockpit-btn {
      height: 42px; padding: 0 16px; border-radius: 11px; border: 1px solid var(--line);
      background: var(--surface2); color: var(--ink); font-weight: 700; cursor: pointer;
      display: inline-flex; align-items: center; justify-content: center; gap: 7px;
      transition: all 0.15s ease;
    }
    .cockpit-btn:hover:not(:disabled) { border-color: var(--accent); }
    .cockpit-btn.primary { background: var(--accent); border-color: var(--accent); color: var(--accent-ink); }
    .cockpit-btn.danger { color: var(--gap); }
    .cockpit-btn.small { height: 32px; padding: 0 11px; font-size: 12.5px; font-weight: 600; border-radius: 8px; }
    .pill { display: inline-flex; align-items: center; gap: 4px; padding: 3px 10px; border-radius: 99px; font-size: 12px; font-weight: 700; white-space: nowrap; }
    .pill.ok { background: color-mix(in srgb, var(--ok) 16%, var(--surface)); color: var(--ok); }
    .pill.warn { background: color-mix(in srgb, var(--warn) 16%, var(--surface)); color: var(--warn); }
    .pill.gap { background: color-mix(in srgb, var(--gap) 16%, var(--surface)); color: var(--gap); }
    .pill.na { background: var(--surface2); color: var(--muted); }
  `;

  /* ==========================================================================
     FALL 1: NICHT EINGELOGGT -> AUTHENTIFIZIERUNGS-SCREEN
     ========================================================================== */
  if (!currentUser) {
    return (
      <>
        <style>{customStyles}</style>
        <div className="min-h-screen flex items-center justify-center p-4">
          <div className="w-full max-w-md overflow-hidden rounded-2xl border shadow-xl" style={{ background: 'var(--surface)', borderColor: 'var(--line)' }}>
            <div className="p-6" style={{ background: 'var(--hero-bg)', color: 'var(--hero-ink)' }}>
              <div className="flex items-center justify-between text-xs uppercase tracking-wider font-semibold" style={{ color: 'var(--hero-muted)' }}>
                <span>Fullstack App · LiteDB + Cloud</span>
                <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px]" style={{ background: 'var(--hero-track)', color: 'var(--hero-fill)' }}>
                  <Database className="w-3 h-3" /> {Object.keys(usersTable).length} User · {Object.keys(articlesTable).length} Artikel
                </span>
              </div>
              <h1 className="text-2xl font-extrabold mt-2">Longevity &amp; Abnehm-Cockpit</h1>
              <p className="text-sm mt-1" style={{ color: 'var(--hero-muted)' }}>
                Multi-User Applikation mit individueller Ziel- &amp; Gewichtshistorie, gemeinsamer Artikel-Datenbank und integriertem DB-Administrator.
              </p>
            </div>

            <div className="p-6 flex flex-col gap-4">
              {/* Modus-Umschalter */}
              <div className="grid grid-cols-2 p-1 rounded-xl border" style={{ background: 'var(--surface2)', borderColor: 'var(--line)' }}>
                <button
                  type="button"
                  onClick={() => { setAuthTab('login'); setAuthError(''); }}
                  className="py-2 rounded-lg text-sm font-bold transition-all"
                  style={authTab === 'login' ? { background: 'var(--accent)', color: 'var(--accent-ink)' } : { color: 'var(--muted)' }}
                >
                  Anmelden
                </button>
                <button
                  type="button"
                  onClick={() => { setAuthTab('register'); setAuthError(''); }}
                  className="py-2 rounded-lg text-sm font-bold transition-all"
                  style={authTab === 'register' ? { background: 'var(--accent)', color: 'var(--accent-ink)' } : { color: 'var(--muted)' }}
                >
                  Neu registrieren
                </button>
              </div>

              {/* 1-Klick Demo-Profile */}
              {Object.keys(usersTable).length > 0 && (
                <div>
                  <div className="text-xs uppercase tracking-wider font-semibold mb-2" style={{ color: 'var(--muted)' }}>
                    Vorhandene Profile (Passwort für Demo: 1234)
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {Object.values(usersTable).map((u) => (
                      <button
                        key={u.username}
                        type="button"
                        onClick={() => {
                          setAuthTab('login');
                          setLoginUser(u.username);
                          setLoginPass('1234');
                        }}
                        className="cockpit-btn small"
                      >
                        <span className="w-5 h-5 rounded-full text-[11px] flex items-center justify-center font-bold" style={{ background: 'var(--accent)', color: 'var(--accent-ink)' }}>
                          {(u.displayName || u.username).slice(0, 1).toUpperCase()}
                        </span>
                        <span>{u.displayName || u.username}</span>
                        {u.role === 'admin' && <Shield className="w-3.5 h-3.5" style={{ color: 'var(--kcal)' }} />}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <form onSubmit={handleAuthSubmit} className="flex flex-col gap-3">
                <label className="flex flex-col gap-1 text-xs uppercase tracking-wider font-semibold" style={{ color: 'var(--muted)' }}>
                  <span>Benutzername</span>
                  <input
                    type="text"
                    className="cockpit-input"
                    value={loginUser}
                    onChange={(e) => setLoginUser(e.target.value)}
                    placeholder="z. B. nadine"
                    required
                  />
                </label>

                {authTab === 'register' && (
                  <div className="grid grid-cols-2 gap-3">
                    <label className="flex flex-col gap-1 text-xs uppercase tracking-wider font-semibold" style={{ color: 'var(--muted)' }}>
                      <span>Anzeigename</span>
                      <input
                        type="text"
                        className="cockpit-input"
                        value={regDisplay}
                        onChange={(e) => setRegDisplay(e.target.value)}
                        placeholder="z. B. Nadine"
                      />
                    </label>
                    <label className="flex flex-col gap-1 text-xs uppercase tracking-wider font-semibold" style={{ color: 'var(--muted)' }}>
                      <span>Berechtigung</span>
                      <select className="cockpit-input" value={regRole} onChange={(e) => setRegRole(e.target.value)}>
                        <option value="member">Standard-User</option>
                        <option value="admin">DB-Administrator</option>
                      </select>
                    </label>
                  </div>
                )}

                <label className="flex flex-col gap-1 text-xs uppercase tracking-wider font-semibold" style={{ color: 'var(--muted)' }}>
                  <span>Passwort</span>
                  <input
                    type="password"
                    className="cockpit-input"
                    value={loginPass}
                    onChange={(e) => setLoginPass(e.target.value)}
                    placeholder="Mindestens 4 Zeichen (Demo: 1234)"
                    required
                  />
                </label>

                {authTab === 'register' && (
                  <div className="grid grid-cols-2 gap-3 pt-2 border-t" style={{ borderColor: 'var(--line)' }}>
                    <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
                      <span>Startgewicht (kg)</span>
                      <input type="number" step="any" className="cockpit-input" value={regStartW} onChange={(e) => setRegStartW(e.target.value)} />
                    </label>
                    <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
                      <span>Zielgewicht (kg)</span>
                      <input type="number" step="any" className="cockpit-input" value={regGoalW} onChange={(e) => setRegGoalW(e.target.value)} />
                    </label>
                    <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
                      <span>Kalorienziel</span>
                      <input type="number" className="cockpit-input" value={regKcal} onChange={(e) => setRegKcal(e.target.value)} />
                    </label>
                    <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
                      <span>Protein Min (g)</span>
                      <input type="number" className="cockpit-input" value={regPMin} onChange={(e) => setRegPMin(e.target.value)} />
                    </label>
                  </div>
                )}

                {authError && (
                  <div className="text-sm font-medium px-3 py-2 rounded-lg" style={{ background: 'color-mix(in srgb, var(--gap) 14%, var(--surface))', color: 'var(--gap)' }}>
                    {authError}
                  </div>
                )}

                <button type="submit" className="cockpit-btn primary w-full mt-2">
                  <Lock className="w-4 h-4" />
                  {authTab === 'login' ? 'Im Cockpit anmelden' : 'Benutzerkonto anlegen'}
                </button>
              </form>
            </div>
          </div>
        </div>
      </>
    );
  }

  /* ==========================================================================
     FALL 2: EINGELOGGTE HAUPT-APPLIKATION
     ========================================================================== */
  const daysSinceStart = Math.max(1, diffDays(parseDate(activeCfg.startDate), parseDate(todayStr())) + 1);
  const totalDbRecords =
    Object.keys(usersTable).length +
    Object.keys(articlesTable).length +
    Object.keys(weightsTable).length +
    Object.keys(daysTable).length;

  return (
    <>
      <style>{customStyles}</style>
      <div className="max-w-[1120px] mx-auto px-4 pt-4 pb-28 md:py-6 flex flex-col gap-4">
        {/* TOP HEADER */}
        <header className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl md:text-3xl font-extrabold">Longevity &amp; Abnehm-Cockpit</h1>
              <span className="pill ok text-[11px]">v2.4 Fullstack</span>
            </div>
            <p className="text-sm mt-0.5" style={{ color: 'var(--muted)' }}>
              {new Date().toLocaleDateString('de-DE', { weekday: 'long', day: 'numeric', month: 'long' })} · Tag {daysSinceStart} seit Start ({currentUser.displayName || currentUser.username})
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* LiteDB / Cloud Status Badge */}
            <button
              type="button"
              onClick={() => setRoute('dbadmin')}
              className="inline-flex items-center gap-2 text-xs px-3 py-1.5 rounded-full border cursor-pointer"
              style={{ background: 'var(--surface)', borderColor: 'var(--line)', color: 'var(--muted)' }}
              title="Zum integrierten Datenbank-Administrator wechseln"
            >
              <span className="w-2 h-2 rounded-full" style={{ background: syncMode === 'cloud' ? 'var(--ok)' : 'var(--kcal)' }} />
              <Database className="w-3.5 h-3.5" style={{ color: 'var(--accent)' }} />
              <span className="font-semibold" style={{ color: 'var(--ink)' }}>
                {syncMode === 'cloud' ? 'LiteDB + Cloud Sync' : 'LiteDB Engine'}
              </span>
              <span className="num">({totalDbRecords} Rows)</span>
            </button>

            {/* Aktiver Benutzer Schnellwechsel */}
            <button
              type="button"
              onClick={() => setRoute('konto')}
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full border font-bold text-xs cursor-pointer"
              style={{ background: 'var(--surface)', borderColor: 'var(--line)' }}
            >
              <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-extrabold" style={{ background: 'var(--accent)', color: 'var(--accent-ink)' }}>
                {(currentUser.displayName || currentUser.username).slice(0, 1).toUpperCase()}
              </span>
              <span>{currentUser.displayName || currentUser.username}</span>
              {currentUser.role === 'admin' && <Shield className="w-3.5 h-3.5" style={{ color: 'var(--kcal)' }} title="DB-Administrator" />}
            </button>

            <button
              type="button"
              onClick={() => setCurrentUsername(null)}
              className="cockpit-btn small"
              title="Abmelden / Benutzer wechseln"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </header>

        {/* NAVIGATION (7 TABS INKL. DB-ADMIN STUDIO) */}
        <nav
          aria-label="Hauptnavigation"
          className="fixed bottom-0 left-0 right-0 z-30 grid grid-cols-7 border-t p-1.5 md:static md:border md:rounded-xl md:p-1 md:max-w-[920px]"
          style={{ background: 'var(--surface)', borderColor: 'var(--line)' }}
        >
          {[
            { id: 'heute', label: 'Heute', icon: Activity },
            { id: 'verlauf', label: 'Verlauf', icon: TrendingUp },
            { id: 'eintrag', label: 'Eintrag', icon: PlusCircle },
            { id: 'snack', label: 'Snack-O-Mat', icon: Sparkles },
            { id: 'artikel', label: 'Artikel-DB', icon: Utensils },
            { id: 'konto', label: 'Konto', icon: Users },
            { id: 'dbadmin', label: 'DB-Admin', icon: Database }
          ].map((item) => {
            const Icon = item.icon;
            const active = route === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setRoute(item.id)}
                className="flex flex-col md:flex-row items-center justify-center gap-1 md:gap-1.5 py-1.5 px-1 md:px-3 rounded-lg text-[11px] md:text-[13.5px] font-semibold transition-all cursor-pointer truncate"
                style={
                  active
                    ? { color: 'var(--accent)', background: 'color-mix(in srgb, var(--accent) 13%, transparent)', fontWeight: 700 }
                    : { color: 'var(--muted)' }
                }
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* ==================== VIEW 1: HEUTE ==================== */}
        {route === 'heute' && (
          <HeuteView
            currentUser={currentUser}
            cfg={activeCfg}
            prefs={activePrefs}
            weightSeries={weightSeries}
            calcTempo={calcTempo}
            todayDay={userDays[todayStr()]}
            rollingStats={rollingStats}
            userDays={userDays}
            onNavigate={setRoute}
            onToggleTrained={async () => {
              const t = todayStr();
              const docId = `${currentUsername}__${t}`;
              const cur = !!(userDays[t] && userDays[t].trained);
              await dbUpsert('user_days', docId, {
                id: docId,
                username: currentUsername,
                date: t,
                trained: !cur,
                updatedAt: t
              }, true);
              showToast(!cur ? 'Krafttraining für heute eingetragen' : 'Krafttraining entfernt');
            }}
          />
        )}

        {/* ==================== VIEW 2: VERLAUF ==================== */}
        {route === 'verlauf' && (
          <VerlaufView
            currentUser={currentUser}
            cfg={activeCfg}
            weightSeries={weightSeries}
            userWeights={userWeights}
            userDays={userDays}
            wRange={wRange}
            setWRange={setWRange}
            onEditDay={(ds) => {
              setEditingDate(ds);
              setRoute('eintrag');
            }}
          />
        )}

        {/* ==================== VIEW 3: EINTRAG ==================== */}
        {route === 'eintrag' && (
          <EintragView
            currentUser={currentUser}
            editingDate={editingDate}
            setEditingDate={setEditingDate}
            userWeights={userWeights}
            userDays={userDays}
            dbUpsert={dbUpsert}
            dbDelete={dbDelete}
            showToast={showToast}
            onNavigate={setRoute}
          />
        )}

        {/* ==================== VIEW 4: SNACK-O-MAT ==================== */}
        {route === 'snack' && (
          <SnackOMatView
            cfg={activeCfg}
            prefs={activePrefs}
            todayDay={userDays[todayStr()]}
            articlesTable={articlesTable}
            snMissingP={snMissingP}
            setSnMissingP={setSnMissingP}
            snRestKcal={snRestKcal}
            setSnRestKcal={setSnRestKcal}
            onBookArticle={(id, mult) => bookArticle(id, mult, todayStr())}
            onNavigate={setRoute}
            showToast={showToast}
          />
        )}

        {/* ==================== VIEW 5: SHARED ARTIKEL-DB ==================== */}
        {route === 'artikel' && (
          <ArtikelDBView
            articlesTable={articlesTable}
            prefs={activePrefs}
            artSearch={artSearch}
            setArtSearch={setArtSearch}
            artCatFilter={artCatFilter}
            setArtCatFilter={setArtCatFilter}
            artBookDate={artBookDate}
            setArtBookDate={setArtBookDate}
            onToggleFavorite={toggleFavorite}
            onBookArticle={(id, mult) => bookArticle(id, mult, artBookDate)}
            onEditArticle={(art) => setArticleModalData(art)}
            onNewArticle={() =>
              setArticleModalData({
                id: '',
                n: '',
                p: '',
                k: '',
                pr: '',
                carbs: '',
                fat: '',
                fiber: '',
                cat: 'saver',
                gut: '',
                est: false
              })
            }
          />
        )}

        {/* ==================== VIEW 6: KONTO & PRÄFERENZEN ==================== */}
        {route === 'konto' && (
          <KontoView
            currentUser={currentUser}
            cfg={activeCfg}
            prefs={activePrefs}
            usersTable={usersTable}
            weightsTable={weightsTable}
            dbUpsert={dbUpsert}
            showToast={showToast}
            onSwitchUser={(uname) => {
              setCurrentUsername(uname);
              showToast(`Gewechselt zu ${usersTable[uname]?.displayName || uname}`);
            }}
            onLogout={() => setCurrentUsername(null)}
            onOpenDBAdmin={() => setRoute('dbadmin')}
          />
        )}

        {/* ==================== VIEW 7: DB-ADMIN STUDIO ==================== */}
        {route === 'dbadmin' && (
          <DBAdminStudioView
            currentUser={currentUser}
            syncMode={syncMode}
            usersTable={usersTable}
            articlesTable={articlesTable}
            weightsTable={weightsTable}
            daysTable={daysTable}
            auditLog={auditLog}
            adminActiveTable={adminActiveTable}
            setAdminActiveTable={setAdminActiveTable}
            adminSearch={adminSearch}
            setAdminSearch={setAdminSearch}
            sqlInput={sqlInput}
            setSqlInput={setSqlInput}
            sqlResult={sqlResult}
            setSqlResult={setSqlResult}
            sqlError={sqlError}
            setSqlError={setSqlError}
            onEditRecord={(table, id, obj, isNew = false) =>
              setEditingRecordModal({
                table,
                id: id || '',
                jsonText: JSON.stringify(obj, null, 2),
                isNew
              })
            }
            onDeleteRecord={dbDelete}
            onUpsertRecord={dbUpsert}
            onOpenArchModal={() => setShowArchModal(true)}
            showToast={showToast}
          />
        )}
      </div>

      {/* ==================== MODAL: ARTIKEL ANLEGEN / BEARBEITEN ==================== */}
      {articleModalData && (
        <ArticleEditorModal
          initialData={articleModalData}
          currentUser={currentUser}
          onClose={() => setArticleModalData(null)}
          onSave={async (item) => {
            const id = item.id || `art-${Date.now()}`;
            await dbUpsert('shared_articles', id, { ...item, id, updatedAt: todayStr() }, false);
            setArticleModalData(null);
            showToast('Artikel in gemeinsamer Datenbank gespeichert');
          }}
          onDelete={async (id) => {
            await dbDelete('shared_articles', id);
            setArticleModalData(null);
            showToast('Artikel aus Datenbank gelöscht');
          }}
        />
      )}

      {/* ==================== MODAL: RAW DB-RECORD JSON EDITOR ==================== */}
      {editingRecordModal && (
        <RawRecordModal
          modal={editingRecordModal}
          setModal={setEditingRecordModal}
          onSave={async () => {
            try {
              const parsed = JSON.parse(editingRecordModal.jsonText);
              const pkField = DB_SCHEMA[editingRecordModal.table]?.pk || 'id';
              const recordId = parsed[pkField] || editingRecordModal.id || `rec-${Date.now()}`;
              parsed[pkField] = recordId;
              await dbUpsert(editingRecordModal.table, recordId, parsed, false);
              setEditingRecordModal(null);
              showToast(`Datensatz "${recordId}" in ${editingRecordModal.table} gespeichert`);
            } catch (e) {
              showToast('Ungültiges JSON-Format: ' + e.message);
            }
          }}
        />
      )}

      {/* ==================== MODAL: GITHUB & VERCEL FULLSTACK PROJEKT-GENERATOR ==================== */}
      {showArchModal && (
        <VercelArchitectureModal
          dbTables={{
            app_users: usersTable,
            shared_articles: articlesTable,
            user_weights: weightsTable,
            user_days: daysTable
          }}
          onClose={() => setShowArchModal(false)}
          showToast={showToast}
        />
      )}

      {/* TOAST NOTIFICATION */}
      {toastMsg && (
        <div
          role="status"
          className="fixed left-1/2 -translate-x-1/2 bottom-20 md:bottom-8 z-50 px-5 py-2.5 rounded-full text-sm font-semibold shadow-2xl"
          style={{ background: 'var(--ink)', color: 'var(--bg)' }}
        >
          {toastMsg}
        </div>
      )}
    </>
  );
}

/* ============================================================================
   SUB-VIEW 1: HEUTE (HERO, TEMPO-GAUGE, RADAR, METERS, BIG ROCKS)
   ============================================================================ */
function HeuteView({ currentUser, cfg, prefs, weightSeries, calcTempo, todayDay, rollingStats, userDays, onNavigate, onToggleTrained }) {
  const lastPoint = weightSeries.length ? weightSeries[weightSeries.length - 1] : null;
  const corridorParts = (prefs.corridor || '0.4-0.7').split('-').map(Number);
  const rLo = corridorParts[0] || 0.4;
  const rHi = corridorParts[1] || 0.7;

  const t14 = calcTempo(weightSeries, 14);
  const t28 = calcTempo(weightSeries, 28);

  const monthRange = (cur, target) => {
    if (cur <= target) return 'erreicht 🎉';
    const d1 = addDays(new Date(), Math.round(((cur - target) / rHi) * 7));
    const d2 = addDays(new Date(), Math.round(((cur - target) / rLo) * 7));
    const f = (d) => d.toLocaleDateString('de-DE', { month: 'short', year: 'numeric' });
    const a = f(d1);
    const b = f(d2);
    return a === b ? a : `${a} bis ${b}`;
  };

  // Radar-Coaching-Logik
  let radarText = 'Alles im Korridor. Der rollierende 7-Tage-Schnitt zählt, nicht der einzelne Tag.';
  let radarAction = null;
  if (t14 !== null && t14 > 0.8) {
    radarText = `Im 14-Tage-Trend gehen ${nf2.format(t14)} kg pro Woche runter, das liegt über 0,8. Iss etwas mehr (~100 bis 150 kcal pro Tag), sonst geht Muskelmasse verloren.`;
  } else if (rollingStats.kcal !== null && rollingStats.kcal < 1500) {
    radarText = `Im Schnitt sind es ${nf0.format(rollingStats.kcal)} kcal, das ist unter der Linie von 1.500. Heb die Zufuhr an, Crash-Tempo bringt langfristig nichts.`;
  } else if (rollingStats.protein !== null && rollingStats.protein < cfg.proteinMin - 5) {
    radarText = `Protein liegt im 7-Tage-Schnitt bei ${nf0.format(rollingStats.protein)} g, dein Zielband beginnt bei ${nf0.format(cfg.proteinMin)} g. Eine Portion Harzer Käse oder Magerquark schließt das meist.`;
    radarAction = { label: 'Zum Snack-O-Mat', route: 'snack' };
  } else if (rollingStats.fiber !== null && rollingStats.fiber < 35) {
    radarText = `Ballaststoffe im Schnitt ${nf0.format(rollingStats.fiber)} g, Ziel ${nf0.format(cfg.fiber)} g. Linsen, Kichererbsen, Beeren und Haferflocken sind die einfachsten Hebel.`;
  }

  const span = (cfg.startWeight - cfg.goal) || 1;
  const pos = (w) => clamp(((cfg.startWeight - w) / span) * 100, 0, 100);
  const pe = pos(cfg.etappe);
  const pc = lastPoint ? pos(lastPoint.t) : 0;
  const pcn = (v) => clamp(((v - -0.2) / (1.0 - -0.2)) * 100, 0, 100);

  return (
    <div className="flex flex-col gap-4">
      {/* HERO GEWICHTSTREND */}
      <section className="rounded-2xl p-5 flex flex-col gap-4" style={{ background: 'var(--hero-bg)', color: 'var(--hero-ink)' }}>
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <div className="text-xs uppercase tracking-wider font-semibold" style={{ color: 'var(--hero-muted)' }}>
              Gewichtstrend (Libra-Glättung) · {currentUser.displayName || currentUser.username}
            </div>
            <div className="font-display font-extrabold text-5xl md:text-6xl num mt-1">
              {lastPoint ? nf1.format(lastPoint.t) : '–'}
              <small className="text-xl font-medium ml-1.5" style={{ color: 'var(--hero-muted)' }}>kg</small>
            </div>
            <div className="text-xs mt-1.5" style={{ color: 'var(--hero-muted)' }}>
              {lastPoint
                ? `Letzte Messung ${nf1.format(lastPoint.w)} kg am ${fmtDM(lastPoint.date)}`
                : 'Noch keine Messung vorhanden. Trage dein Gewicht im Reiter Eintrag ein.'}
            </div>
          </div>

          {lastPoint && (
            <div className="font-display font-bold text-base px-3.5 py-1.5 rounded-full num" style={{ background: 'var(--hero-track)' }}>
              {cfg.startWeight - lastPoint.t >= 0 ? '−' : '+'}
              {nf1.format(Math.abs(cfg.startWeight - lastPoint.t))} kg seit Start
            </div>
          )}
        </div>

        {lastPoint && (
          <>
            {/* Etappen-Balken */}
            <div className="pt-1">
              <div className="relative h-3 rounded-full" style={{ background: 'var(--hero-track)' }}>
                <div className="absolute left-0 top-0 bottom-0 rounded-full" style={{ width: `${pc}%`, background: 'var(--hero-fill)', minWidth: '12px' }} />
                <i className="absolute -top-1 w-0.5 h-5 opacity-75" style={{ left: `calc(${pe}% - 1px)`, background: 'var(--hero-ink)' }} />
              </div>
              <div className="relative h-9 mt-1.5 text-xs" style={{ color: 'var(--hero-muted)' }}>
                <span className="absolute left-0">
                  <b className="block font-display text-sm num" style={{ color: 'var(--hero-ink)' }}>{nf1.format(cfg.startWeight)}</b>Start
                </span>
                <span className="absolute -translate-x-1/2 text-center" style={{ left: `${pe}%` }}>
                  <b className="block font-display text-sm num" style={{ color: 'var(--hero-ink)' }}>{nf1.format(cfg.etappe)}</b>Etappe
                </span>
                <span className="absolute right-0 text-right">
                  <b className="block font-display text-sm num" style={{ color: 'var(--hero-ink)' }}>{nf1.format(cfg.goal)}</b>Ziel
                </span>
              </div>
            </div>

            {/* Tempo & Prognose */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t" style={{ borderColor: 'var(--hero-line)' }}>
              <div>
                <h3 className="text-sm font-bold mb-2">Tempo</h3>
                {t14 === null ? (
                  <p className="text-xs" style={{ color: 'var(--hero-muted)' }}>Für das Tempo braucht es Messungen über mindestens 14 Tage.</p>
                ) : (
                  <>
                    <div className="flex justify-between text-sm py-0.5">
                      <span>Letzte 14 Tage</span>
                      <b className="font-display num">{t14 > 0 ? '−' : '+'}{nf2.format(Math.abs(t14))} kg/Woche</b>
                    </div>
                    {t28 !== null && (
                      <div className="flex justify-between text-sm py-0.5">
                        <span>Letzte 28 Tage</span>
                        <b className="font-display num">{t28 > 0 ? '−' : '+'}{nf2.format(Math.abs(t28))} kg/Woche</b>
                      </div>
                    )}
                    <div className="relative h-2.5 rounded-full my-3" style={{ background: 'var(--hero-track)' }}>
                      <div
                        className="absolute top-0 bottom-0 rounded-full opacity-35"
                        style={{ left: `${pcn(rLo)}%`, width: `${pcn(rHi) - pcn(rLo)}%`, background: 'var(--hero-fill)' }}
                      />
                      <i
                        className="absolute -top-1 w-1.5 h-4 rounded -translate-x-1/2"
                        style={{ left: `${pcn(t14)}%`, background: 'var(--hero-ink)' }}
                      />
                    </div>
                    <div className="flex justify-between text-[11px]" style={{ color: 'var(--hero-muted)' }}>
                      <span>0,0</span>
                      <span>Korridor {nf1.format(rLo)} – {nf1.format(rHi)} kg/Wo</span>
                      <span>1,0</span>
                    </div>
                  </>
                )}
              </div>

              <div>
                <h3 className="text-sm font-bold mb-2">Prognose im Korridor</h3>
                <div className="flex justify-between text-sm py-0.5">
                  <span>Noch {nf1.format(Math.max(0, lastPoint.t - cfg.etappe))} kg bis Etappe ({nf0.format(cfg.etappe)} kg)</span>
                  <b className="font-display num">{monthRange(lastPoint.t, cfg.etappe)}</b>
                </div>
                <div className="flex justify-between text-sm py-0.5">
                  <span>Noch {nf1.format(Math.max(0, lastPoint.t - cfg.goal))} kg bis Ziel ({nf0.format(cfg.goal)} kg)</span>
                  <b className="font-display num">{monthRange(lastPoint.t, cfg.goal)}</b>
                </div>
                <p className="text-xs mt-2" style={{ color: 'var(--hero-muted)' }}>
                  Berechnet mit {nf1.format(rLo)} bis {nf1.format(rHi)} kg/Woche ab deinem aktuellen Trend.
                </p>
              </div>
            </div>
          </>
        )}
      </section>

      {/* RADAR COACHING */}
      <div className="cockpit-card border-l-4" style={{ borderLeftColor: 'var(--accent)' }}>
        <div className="text-xs uppercase tracking-wider font-bold" style={{ color: 'var(--accent)' }}>Radar · Coaching-Impuls</div>
        <p className="mt-1 text-sm">{radarText}</p>
        {radarAction && (
          <button type="button" onClick={() => onNavigate(radarAction.route)} className="cockpit-btn small mt-2">
            {radarAction.label}
          </button>
        )}
      </div>

      {/* HEUTE METERS & BIG ROCKS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <section className="cockpit-card lg:col-span-7 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-baseline mb-3">
              <h2 className="text-lg font-bold">Heute</h2>
              <span className="text-xs" style={{ color: 'var(--muted)' }}>{fmtWD(todayStr())}</span>
            </div>

            {!todayDay ? (
              <p className="text-sm py-4" style={{ color: 'var(--muted)' }}>
                Für heute sind noch keine Werte eingetragen. Buche direkt einen Artikel aus der Datenbank oder trage deine Tageswerte ein.
              </p>
            ) : (
              <div className="flex flex-col gap-3.5">
                <MacroMeter
                  label="Kalorien"
                  val={num(todayDay.kcal)}
                  max={Math.max(cfg.kcal * 1.15, (todayDay.kcal || 0) * 1.02)}
                  goalText={`${nf0.format(cfg.kcal)} kcal`}
                  color="var(--kcal)"
                  fillColor={num(todayDay.kcal) > cfg.kcal ? 'var(--over)' : 'var(--kcal)'}
                  tick={cfg.kcal}
                  note={
                    num(todayDay.kcal) !== null
                      ? cfg.kcal - todayDay.kcal >= 0
                        ? `Rest-Budget ${nf0.format(cfg.kcal - todayDay.kcal)} kcal.`
                        : `${nf0.format(todayDay.kcal - cfg.kcal)} kcal über Tagesziel.`
                      : 'Noch keine Kalorien erfasst.'
                  }
                />
                <MacroMeter
                  label="Protein"
                  val={num(todayDay.protein)}
                  max={Math.max(cfg.proteinMax * 1.1, (todayDay.protein || 0) * 1.02)}
                  goalText={`${nf0.format(cfg.proteinMin)} – ${nf0.format(cfg.proteinMax)} g`}
                  color="var(--protein)"
                  band={[cfg.proteinMin, cfg.proteinMax]}
                  note={
                    num(todayDay.protein) !== null
                      ? todayDay.protein >= cfg.proteinMin
                        ? 'Im Zielband.'
                        : `Noch ${nf0.format(cfg.proteinMin - todayDay.protein)} g bis zur Untergrenze.`
                      : 'Noch kein Protein erfasst.'
                  }
                />
                <MacroMeter
                  label="Ballaststoffe"
                  val={num(todayDay.fiber)}
                  max={Math.max(cfg.fiber * 1.2, (todayDay.fiber || 0) * 1.02)}
                  goalText={`${nf0.format(cfg.fiber)} g`}
                  color="var(--fiber)"
                  tick={cfg.fiber}
                  note={
                    num(todayDay.fiber) !== null
                      ? todayDay.fiber >= 35
                        ? 'Darm-Zielbereich erreicht.'
                        : `Noch ${nf0.format(35 - todayDay.fiber)} g bis 35 g.`
                      : 'Kein Ballaststoff-Wert.'
                  }
                />
                <MacroMeter
                  label="Schritte"
                  val={num(todayDay.steps)}
                  max={Math.max(cfg.steps * 1.35, (todayDay.steps || 0) * 1.02)}
                  goalText={nf0.format(cfg.steps)}
                  color="var(--steps)"
                  tick={cfg.steps}
                  note={
                    num(todayDay.steps) !== null
                      ? todayDay.steps >= cfg.steps
                        ? 'Schrittziel erreicht!'
                        : `Noch ${nf0.format(cfg.steps - todayDay.steps)} Schritte.`
                      : 'Noch keine Schritte.'
                  }
                />
              </div>
            )}

            {todayDay?.bookedArticles?.length > 0 && (
              <div className="mt-4 pt-3 border-t" style={{ borderColor: 'var(--line)' }}>
                <div className="text-[11px] uppercase tracking-wider font-bold mb-1.5" style={{ color: 'var(--muted)' }}>
                  Heute gebuchte Artikel aus der Datenbank
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {todayDay.bookedArticles.map((b, i) => (
                    <span key={i} className="pill na text-xs">
                      {b.mult !== 1 ? `${nf1.format(b.mult)}× ` : ''}{b.name} ({nf0.format(b.kcal)} kcal · {nf0.format(b.protein)}g P)
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t" style={{ borderColor: 'var(--line)' }}>
            <button
              type="button"
              onClick={onToggleTrained}
              className="cockpit-btn small"
              style={todayDay?.trained ? { background: 'var(--accent)', color: 'var(--accent-ink)', borderColor: 'var(--accent)' } : {}}
            >
              <Check className="w-3.5 h-3.5" /> Krafttraining heute
            </button>
            <button type="button" onClick={() => onNavigate('eintrag')} className="cockpit-btn small">
              Werte ergänzen
            </button>
            <button type="button" onClick={() => onNavigate('snack')} className="cockpit-btn small">
              Snack-O-Mat
            </button>
            <button type="button" onClick={() => onNavigate('artikel')} className="cockpit-btn small primary">
              + Artikel buchen
            </button>
          </div>
        </section>

        {/* BIG ROCKS 7-TAGE SCHNITT */}
        <section className="cockpit-card lg:col-span-5">
          <div className="flex justify-between items-baseline mb-3">
            <h2 className="text-lg font-bold">Big Rocks</h2>
            <span className="text-xs" style={{ color: 'var(--muted)' }}>Ø letzte 7 Tage bis gestern</span>
          </div>

          {!rollingStats.n ? (
            <p className="text-sm py-4" style={{ color: 'var(--muted)' }}>Noch keine abgeschlossenen Tage vorhanden.</p>
          ) : (
            <>
              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="border-b text-xs uppercase" style={{ borderColor: 'var(--line)', color: 'var(--muted)' }}>
                    <th className="py-2 text-left">Kennzahl</th>
                    <th className="py-2 text-right">Ø 7 Tage</th>
                    <th className="py-2 text-right">Ziel</th>
                    <th className="py-2 text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y" style={{ borderColor: 'var(--line)' }}>
                  <tr>
                    <td className="py-2.5">Kalorien</td>
                    <td className="py-2.5 text-right font-bold num">{rollingStats.kcal ? `${nf0.format(rollingStats.kcal)} kcal` : '–'}</td>
                    <td className="py-2.5 text-right num text-xs" style={{ color: 'var(--muted)' }}>bis {nf0.format(cfg.kcal)}</td>
                    <td className="py-2.5 text-right">
                      <span className={`pill ${rollingStats.kcal <= cfg.kcal * 1.02 ? 'ok' : 'warn'}`}>
                        {rollingStats.kcal <= cfg.kcal * 1.02 ? 'im Defizit' : 'über Ziel'}
                      </span>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2.5">Protein</td>
                    <td className="py-2.5 text-right font-bold num">{rollingStats.protein ? `${nf0.format(rollingStats.protein)} g` : '–'}</td>
                    <td className="py-2.5 text-right num text-xs" style={{ color: 'var(--muted)' }}>{nf0.format(cfg.proteinMin)}–{nf0.format(cfg.proteinMax)} g</td>
                    <td className="py-2.5 text-right">
                      <span className={`pill ${rollingStats.protein >= cfg.proteinMin ? 'ok' : 'warn'}`}>
                        {rollingStats.protein >= cfg.proteinMin ? 'im Band' : 'knapp'}
                      </span>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2.5">Ballaststoffe</td>
                    <td className="py-2.5 text-right font-bold num">{rollingStats.fiber ? `${nf0.format(rollingStats.fiber)} g` : '–'}</td>
                    <td className="py-2.5 text-right num text-xs" style={{ color: 'var(--muted)' }}>35–{nf0.format(cfg.fiber)} g</td>
                    <td className="py-2.5 text-right">
                      <span className={`pill ${rollingStats.fiber >= 35 ? 'ok' : 'warn'}`}>
                        {rollingStats.fiber >= 35 ? 'im Bereich' : 'ausbaufähig'}
                      </span>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2.5">Schritte</td>
                    <td className="py-2.5 text-right font-bold num">{rollingStats.steps ? nf0.format(rollingStats.steps) : '–'}</td>
                    <td className="py-2.5 text-right num text-xs" style={{ color: 'var(--muted)' }}>{nf0.format(cfg.steps)}</td>
                    <td className="py-2.5 text-right">
                      <span className={`pill ${rollingStats.steps >= cfg.steps ? 'ok' : 'warn'}`}>
                        {rollingStats.steps >= cfg.steps ? 'erreicht' : 'knapp'}
                      </span>
                    </td>
                  </tr>
                  <tr>
                    <td className="py-2.5">Krafttraining</td>
                    <td className="py-2.5 text-right font-bold num">{rollingStats.trained} Einh.</td>
                    <td className="py-2.5 text-right num text-xs" style={{ color: 'var(--muted)' }}>3 / Woche</td>
                    <td className="py-2.5 text-right">
                      <span className={`pill ${rollingStats.trained >= 3 ? 'ok' : 'warn'}`}>
                        {rollingStats.trained >= 3 ? '3+ erreicht' : 'dranbleiben'}
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
              <p className="text-xs mt-3" style={{ color: 'var(--muted)' }}>
                Basis: {rollingStats.n} abgeschlossene Tage. Ein einzelner Ausreißer zählt nur im Schnitt.
              </p>
            </>
          )}
        </section>
      </div>
    </div>
  );
}

function MacroMeter({ label, val, max, goalText, color, fillColor, band, tick, note }) {
  const has = val !== null && val !== undefined;
  const w = has ? clamp((val / max) * 100, 0, 100) : 0;
  return (
    <div>
      <div className="flex justify-between items-baseline text-sm">
        <span className="font-bold flex items-center gap-2">
          <i className="w-2.5 h-2.5 rounded-sm inline-block" style={{ background: color }} />
          {label}
        </span>
        <span className="num text-xs" style={{ color: 'var(--muted)' }}>
          <b className="font-display text-base" style={{ color: 'var(--ink)' }}>{has ? nf0.format(val) : '–'}</b> / {goalText}
        </span>
      </div>
      <div className="relative h-2.5 rounded-full border mt-1.5" style={{ background: 'var(--surface2)', borderColor: 'var(--line)' }}>
        {band && (
          <i
            className="absolute top-0 bottom-0"
            style={{
              left: `${(band[0] / max) * 100}%`,
              width: `${((band[1] - band[0]) / max) * 100}%`,
              background: 'color-mix(in srgb, var(--ink) 10%, transparent)'
            }}
          />
        )}
        <div className="absolute left-0 top-0 bottom-0 rounded-full" style={{ width: `${w}%`, background: fillColor || color }} />
        {tick != null && (
          <i className="absolute -top-1 -bottom-1 w-0.5 opacity-60" style={{ left: `calc(${(tick / max) * 100}% - 1px)`, background: 'var(--ink)' }} />
        )}
      </div>
      {note && <div className="text-xs mt-1" style={{ color: 'var(--muted)' }}>{note}</div>}
    </div>
  );
}

/* ============================================================================
   SUB-VIEW 2: VERLAUF (SVG GEWICHTS-CHART, KALORIEN & PROTEIN BARS, 14-TAGE LISTE)
   ============================================================================ */
function VerlaufView({ currentUser, cfg, weightSeries, userWeights, userDays, wRange, setWRange, onEditDay }) {
  const [hoverWeightPt, setHoverWeightPt] = useState(null);

  const pts = useMemo(() => {
    if (!weightSeries.length) return [];
    const last = weightSeries[weightSeries.length - 1];
    const from = wRange === 'all' ? weightSeries[0].d : addDays(last.d, -Number(wRange));
    return weightSeries.filter((p) => p.d >= from);
  }, [weightSeries, wRange]);

  const last14Days = useMemo(() => {
    const arr = [];
    for (let i = 13; i >= 0; i--) {
      const ds = ymd(addDays(new Date(), -i));
      arr.push({
        ds,
        d: userDays[ds] || {},
        w: userWeights[ds] || {}
      });
    }
    return arr;
  }, [userDays, userWeights]);

  // SVG Koordinaten für Gewichts-Chart
  const chartW = 720;
  const chartH = 260;
  const padM = { l: 42, r: 18, t: 16, b: 28 };
  const iw = chartW - padM.l - padM.r;
  const ih = chartH - padM.t - padM.b;

  let lo = 75;
  let hi = 95;
  if (pts.length) {
    const vals = pts.flatMap((p) => [p.w, p.t]);
    if (wRange === 'all') vals.push(cfg.etappe, cfg.goal);
    lo = Math.floor(Math.min(...vals) - 0.5);
    hi = Math.ceil(Math.max(...vals) + 0.5);
  }
  const t0 = pts.length ? pts[0].d.getTime() : 0;
  const t1 = pts.length ? Math.max(pts[pts.length - 1].d.getTime(), t0 + 86400000) : 1;
  const X = (d) => padM.l + ((d.getTime() - t0) / (t1 - t0)) * iw;
  const Y = (v) => padM.t + ((hi - v) / (hi - lo || 1)) * ih;

  const linePath = pts.map((p, i) => `${i ? 'L' : 'M'}${X(p.d).toFixed(1)} ${Y(p.t).toFixed(1)}`).join(' ');
  const activePt = hoverWeightPt || (pts.length ? pts[pts.length - 1] : null);

  return (
    <div className="flex flex-col gap-4">
      <section className="cockpit-card">
        <div className="flex flex-wrap justify-between items-center gap-2 mb-2">
          <h2 className="text-lg font-bold">Gewichtsverlauf ({currentUser.displayName || currentUser.username})</h2>
          <div className="inline-flex rounded-lg border overflow-hidden" style={{ borderColor: 'var(--line)', background: 'var(--surface2)' }}>
            {[
              { r: '30', label: '30 Tage' },
              { r: '90', label: '90 Tage' },
              { r: 'all', label: 'Weg zum Ziel' }
            ].map((b) => (
              <button
                key={b.r}
                type="button"
                onClick={() => setWRange(b.r)}
                className="px-3 py-1 text-xs font-semibold cursor-pointer"
                style={wRange === b.r ? { background: 'var(--accent)', color: 'var(--accent-ink)' } : { color: 'var(--muted)' }}
              >
                {b.label}
              </button>
            ))}
          </div>
        </div>

        {activePt && (
          <div className="text-sm num mb-2" style={{ color: 'var(--muted)' }}>
            {fmtWD(activePt.date)} · Gemessen <b style={{ color: 'var(--ink)' }}>{nf1.format(activePt.w)} kg</b> · Libra-Trend <b style={{ color: 'var(--accent)' }}>{nf1.format(activePt.t)} kg</b>
          </div>
        )}

        {!pts.length ? (
          <p className="text-sm py-6" style={{ color: 'var(--muted)' }}>Noch keine Gewichtsmessungen vorhanden.</p>
        ) : (
          <svg viewBox={`0 0 ${chartW} ${chartH}`} className="w-full h-auto overflow-visible">
            {[0, 0.25, 0.5, 0.75, 1].map((f, idx) => {
              const val = Math.round((lo + (hi - lo) * f) * 10) / 10;
              const y = Y(val);
              return (
                <g key={idx}>
                  <line x1={padM.l} x2={chartW - padM.r} y1={y} y2={y} stroke="var(--line)" strokeWidth="1" />
                  <text x={padM.l - 8} y={y + 4} textAnchor="end" fontSize="11" fill="var(--muted)">{nf1.format(val)}</text>
                </g>
              );
            })}
            <path d={linePath} fill="none" stroke="var(--accent)" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" />
            {pts.map((p) => (
              <circle
                key={p.date}
                cx={X(p.d)}
                cy={Y(p.w)}
                r="4"
                fill="var(--muted)"
                opacity="0.7"
                className="cursor-pointer"
                onMouseEnter={() => setHoverWeightPt(p)}
              />
            ))}
            {activePt && (
              <circle cx={X(activePt.d)} cy={Y(activePt.t)} r="6" fill="var(--accent)" stroke="var(--surface)" strokeWidth="2.5" />
            )}
          </svg>
        )}
      </section>

      {/* 14-TAGE TABELLE (KLICKBAR ZUM BEARBEITEN) */}
      <section className="cockpit-card">
        <div className="flex justify-between items-baseline mb-3">
          <h2 className="text-lg font-bold">Letzte 14 Tage</h2>
          <span className="text-xs" style={{ color: 'var(--muted)' }}>Zeile antippen zum Bearbeiten</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="border-b text-xs uppercase" style={{ borderColor: 'var(--line)', color: 'var(--muted)' }}>
                <th className="py-2 text-left">Datum</th>
                <th className="py-2 text-right">kg</th>
                <th className="py-2 text-right">kcal</th>
                <th className="py-2 text-right">Protein</th>
                <th className="py-2 text-right">Ballast.</th>
                <th className="py-2 text-right">Schritte</th>
                <th className="py-2 text-right">Kraft</th>
              </tr>
            </thead>
            <tbody className="divide-y" style={{ borderColor: 'var(--line)' }}>
              {[...last14Days].reverse().map(({ ds, d, w }) => (
                <tr
                  key={ds}
                  onClick={() => onEditDay(ds)}
                  className="cursor-pointer hover:opacity-80"
                >
                  <td className="py-2.5 font-medium">{fmtWD(ds)}</td>
                  <td className="py-2.5 text-right num">{num(w.weight) !== null ? nf1.format(w.weight) : '–'}</td>
                  <td className="py-2.5 text-right num">{num(d.kcal) !== null ? nf0.format(d.kcal) : '–'}</td>
                  <td className="py-2.5 text-right num">{num(d.protein) !== null ? `${nf0.format(d.protein)} g` : '–'}</td>
                  <td className="py-2.5 text-right num">{num(d.fiber) !== null ? `${nf1.format(d.fiber)} g` : '–'}</td>
                  <td className="py-2.5 text-right num">{num(d.steps) !== null ? nf0.format(d.steps) : '–'}</td>
                  <td className="py-2.5 text-right">{d.trained ? <span className="pill ok">Ja</span> : '–'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

/* ============================================================================
   SUB-VIEW 3: EINTRAG (TAGESWERTE, KI-SCREENSHOT-LESER, CSV-IMPORT)
   ============================================================================ */
function EintragView({ currentUser, editingDate, setEditingDate, userWeights, userDays, dbUpsert, dbDelete, showToast, onNavigate }) {
  const u = currentUser.username;
  const exW = userWeights[editingDate];
  const exD = userDays[editingDate];

  const [weight, setWeight] = useState('');
  const [kcal, setKcal] = useState('');
  const [protein, setProtein] = useState('');
  const [carbs, setCarbs] = useState('');
  const [fat, setFat] = useState('');
  const [fiber, setFiber] = useState('');
  const [steps, setSteps] = useState('');
  const [trained, setTrained] = useState(false);
  const [scanStatus, setScanStatus] = useState('');

  useEffect(() => {
    setWeight(exW?.weight ?? '');
    setKcal(exD?.kcal ?? '');
    setProtein(exD?.protein ?? '');
    setCarbs(exD?.carbs ?? '');
    setFat(exD?.fat ?? '');
    setFiber(exD?.fiber ?? '');
    setSteps(exD?.steps ?? '');
    setTrained(!!exD?.trained);
  }, [editingDate, exW, exD]);

  const toNum = (v) => {
    if (v === '' || v === null || v === undefined) return null;
    const n = Number(String(v).replace(',', '.'));
    return isFinite(n) ? n : null;
  };

  const handleSave = async (e) => {
    e.preventDefault();
    const wVal = toNum(weight);
    const docId = `${u}__${editingDate}`;
    if (wVal !== null) {
      await dbUpsert('user_weights', docId, { id: docId, username: u, date: editingDate, weight: wVal, updatedAt: todayStr() }, false);
    }
    const dayObj = {
      id: docId,
      username: u,
      date: editingDate,
      kcal: toNum(kcal),
      protein: toNum(protein),
      carbs: toNum(carbs),
      fat: toNum(fat),
      fiber: toNum(fiber),
      steps: toNum(steps),
      trained,
      bookedArticles: exD?.bookedArticles || [],
      updatedAt: todayStr()
    };
    await dbUpsert('user_days', docId, dayObj, true);
    showToast(`Tageswerte für ${fmtDM(editingDate)} gespeichert`);
  };

  const handleAIScreenshot = async (file) => {
    if (!file) return;
    setScanStatus('Analysiert FDDB-Screenshot per Gemini KI…');
    try {
      const base64Data = await new Promise((res, rej) => {
        const r = new FileReader();
        r.onload = () => res(String(r.result).split(',')[1]);
        r.onerror = rej;
        r.readAsDataURL(file);
      });
      const apiKey = '';
      const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3-flash-preview:generateContent?key=${apiKey}`;
      const prompt = 'Lies aus diesem FDDB Ernährungs-Screenshot nur sichtbare Tagessummen ab und antworte als JSON: {"kcal":Zahl oder null,"protein":Zahl oder null,"carbs":Zahl oder null,"fat":Zahl oder null,"fiber":Zahl oder null}';
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ role: 'user', parts: [{ text: prompt }, { inlineData: { mimeType: file.type || 'image/png', data: base64Data } }] }],
          generationConfig: { responseMimeType: 'application/json' }
        })
      });
      const result = await response.json();
      const parsed = JSON.parse(result?.candidates?.[0]?.content?.parts?.[0]?.text || '{}');
      if (parsed.kcal != null) setKcal(Math.round(parsed.kcal));
      if (parsed.protein != null) setProtein(Math.round(parsed.protein * 10) / 10);
      if (parsed.carbs != null) setCarbs(Math.round(parsed.carbs * 10) / 10);
      if (parsed.fat != null) setFat(Math.round(parsed.fat * 10) / 10);
      if (parsed.fiber != null) setFiber(Math.round(parsed.fiber * 10) / 10);
      setScanStatus('Werte erfolgreich übernommen! Bitte oben prüfen und speichern.');
    } catch (err) {
      setScanStatus('Screenshot konnte nicht automatisch gelesen werden. Bitte manuell eintragen.');
    }
  };

  return (
    <div className="flex flex-col gap-4">
      <section className="cockpit-card">
        <div className="flex flex-wrap justify-between items-center gap-2 mb-4">
          <h2 className="text-lg font-bold">Tageswerte eintragen ({currentUser.displayName || u})</h2>
          <div className="flex items-center gap-2">
            <input type="date" className="cockpit-input !w-auto" value={editingDate} onChange={(e) => setEditingDate(e.target.value)} />
            <button type="button" onClick={() => setEditingDate(todayStr())} className="cockpit-btn small">Heute</button>
            <button type="button" onClick={() => setEditingDate(ymd(addDays(new Date(), -1)))} className="cockpit-btn small">Gestern</button>
          </div>
        </div>

        <form onSubmit={handleSave} className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Gewicht (kg)</span>
            <input type="number" step="any" className="cockpit-input" value={weight} onChange={(e) => setWeight(e.target.value)} placeholder="91,4" />
          </label>
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Kalorien (kcal)</span>
            <input type="number" step="any" className="cockpit-input" value={kcal} onChange={(e) => setKcal(e.target.value)} placeholder="1750" />
          </label>
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Protein (g)</span>
            <input type="number" step="any" className="cockpit-input" value={protein} onChange={(e) => setProtein(e.target.value)} placeholder="128" />
          </label>
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Ballaststoffe (g)</span>
            <input type="number" step="any" className="cockpit-input" value={fiber} onChange={(e) => setFiber(e.target.value)} placeholder="40" />
          </label>
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Kohlenhydrate (g)</span>
            <input type="number" step="any" className="cockpit-input" value={carbs} onChange={(e) => setCarbs(e.target.value)} />
          </label>
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Fett (g)</span>
            <input type="number" step="any" className="cockpit-input" value={fat} onChange={(e) => setFat(e.target.value)} />
          </label>
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Schritte</span>
            <input type="number" className="cockpit-input" value={steps} onChange={(e) => setSteps(e.target.value)} placeholder="10500" />
          </label>
          <div className="flex items-end">
            <button
              type="button"
              onClick={() => setTrained(!trained)}
              className="cockpit-btn w-full"
              style={trained ? { background: 'var(--accent)', color: 'var(--accent-ink)', borderColor: 'var(--accent)' } : {}}
            >
              <Check className="w-4 h-4" /> Krafttraining
            </button>
          </div>

          <div className="col-span-full flex flex-wrap justify-between items-center gap-2 pt-3 border-t mt-2" style={{ borderColor: 'var(--line)' }}>
            <div className="flex gap-2">
              <button type="submit" className="cockpit-btn primary">Speichern</button>
              <button type="button" onClick={() => onNavigate('artikel')} className="cockpit-btn">+ Artikel aus DB buchen</button>
            </div>
            {(exW || exD) && (
              <button
                type="button"
                onClick={async () => {
                  const id = `${u}__${editingDate}`;
                  await dbDelete('user_weights', id);
                  await dbDelete('user_days', id);
                  showToast(`Eintrag vom ${fmtDM(editingDate)} gelöscht`);
                }}
                className="cockpit-btn danger small"
              >
                <Trash2 className="w-3.5 h-3.5" /> Tag löschen
              </button>
            )}
          </div>
        </form>
      </section>

      {/* KI SCREENSHOT SCANNER */}
      <section className="cockpit-card flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-base flex items-center gap-2">
            <Camera className="w-4 h-4" style={{ color: 'var(--accent)' }} /> FDDB-Screenshot per KI auslesen
          </h3>
          <p className="text-xs mt-1" style={{ color: 'var(--muted)' }}>
            Lade einen Screenshot deiner FDDB-Tagesübersicht hoch – Kalorien, Protein, KH, Fett und Ballaststoffe werden automatisch erkannt.
          </p>
          {scanStatus && <p className="text-xs font-semibold mt-1" style={{ color: 'var(--accent)' }}>{scanStatus}</p>}
        </div>
        <label className="cockpit-btn cursor-pointer shrink-0">
          <Upload className="w-4 h-4" /> Screenshot wählen
          <input type="file" accept="image/*" className="hidden" onChange={(e) => handleAIScreenshot(e.target.files?.[0])} />
        </label>
      </section>
    </div>
  );
}

/* ============================================================================
   SUB-VIEW 4: SNACK-O-MAT (GREIFT AUF DIE GEMEINSAME ARTIKEL-DB ZU)
   ============================================================================ */
function SnackOMatView({ cfg, prefs, todayDay, articlesTable, snMissingP, setSnMissingP, snRestKcal, setSnRestKcal, onBookArticle, onNavigate, showToast }) {
  const fillFromToday = useCallback(() => {
    if (!todayDay) {
      showToast('Für heute sind noch keine Werte eingetragen');
      return;
    }
    setSnMissingP(String(Math.max(0, Math.round(cfg.proteinMin - (todayDay.protein || 0)))));
    setSnRestKcal(String(Math.round(cfg.kcal - (todayDay.kcal || 0))));
  }, [todayDay, cfg, setSnMissingP, setSnRestKcal, showToast]);

  useEffect(() => {
    if (snMissingP === '' && snRestKcal === '' && todayDay) {
      fillFromToday();
    }
  }, [todayDay, snMissingP, snRestKcal, fillFromToday]);

  const miss = Number(snMissingP) || 0;
  const rest = Number(snRestKcal) || 0;
  const favSet = new Set(prefs.favorites || []);

  const recommendations = useMemo(() => {
    if (rest <= 0) return [];
    const list = Object.values(articlesTable).filter((a) => a && a.k <= rest);
    const cov = (s) => (miss > 0 ? Math.min(s.pr, miss) : s.pr);
    return list.sort((a, b) => {
      const scoreA = (cov(a) / a.k) * (favSet.has(a.id) ? 1.1 : 1);
      const scoreB = (cov(b) / b.k) * (favSet.has(b.id) ? 1.1 : 1);
      return scoreB - scoreA;
    }).slice(0, 4);
  }, [articlesTable, miss, rest, favSet]);

  return (
    <div className="flex flex-col gap-4">
      <section className="cockpit-card">
        <div className="flex flex-wrap justify-between items-baseline gap-2 mb-3">
          <div>
            <h2 className="text-lg font-bold">Snack-O-Mat</h2>
            <p className="text-xs" style={{ color: 'var(--muted)' }}>
              Berechnet aus allen {Object.keys(articlesTable).length} Artikeln der gemeinsamen Datenbank die optimale Punktlandung
            </p>
          </div>
          <button type="button" onClick={fillFromToday} className="cockpit-btn small">
            Aus heutigen Werten übernehmen
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-md">
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Fehlendes Protein (g)</span>
            <input type="number" className="cockpit-input" value={snMissingP} onChange={(e) => setSnMissingP(e.target.value)} placeholder="25" />
          </label>
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Rest-Budget (kcal)</span>
            <input type="number" className="cockpit-input" value={snRestKcal} onChange={(e) => setSnRestKcal(e.target.value)} placeholder="350" />
          </label>
        </div>
      </section>

      {rest <= 0 ? (
        <div className="cockpit-card">
          <h3 className="font-bold text-base">Küche zu · Tagesbudget erreicht</h3>
          <p className="text-sm mt-1" style={{ color: 'var(--muted)' }}>
            Dein Kalorienbudget für heute ist ausgeschöpft. Defizit schlägt Makro-Perfektion – plane morgen früh direkt eine Portion Skyr oder Magerquark ein.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {recommendations.map((s, idx) => (
            <article key={s.id} className="cockpit-card flex flex-col justify-between gap-2">
              <div>
                <div className="flex justify-between items-center text-xs font-bold uppercase tracking-wider" style={{ color: 'var(--accent)' }}>
                  <span>{idx === 0 ? 'Top Defizit-Retter (Beste Effizienz)' : s.cat === 'upgrade' ? 'Longevity-Upgrade' : 'Passende Alternative'}</span>
                  {favSet.has(s.id) && <span>★ Favorit</span>}
                </div>
                <h3 className="text-lg font-bold mt-1">{s.n}</h3>
                <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{s.p}</p>
                <div className="flex flex-wrap gap-3 font-display font-bold text-sm mt-2 num">
                  <span style={{ color: 'var(--kcal)' }}>{nf0.format(s.k)} kcal</span>
                  <span style={{ color: 'var(--protein)' }}>{nf1.format(s.pr)} g Protein</span>
                  {num(s.fiber) > 0 && <span style={{ color: 'var(--fiber)' }}>{nf1.format(s.fiber)} g Ballast.</span>}
                </div>
              </div>

              <div className="flex justify-between items-center pt-2 border-t mt-2" style={{ borderColor: 'var(--line)' }}>
                {s.gut ? <span className="pill ok text-xs">{s.gut}</span> : <span className="text-xs" style={{ color: 'var(--muted)' }}>Autor: {s.author || 'System'}</span>}
                <button type="button" onClick={() => onBookArticle(s.id, 1)} className="cockpit-btn small primary">
                  + Heute buchen
                </button>
              </div>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}

/* ============================================================================
   SUB-VIEW 5: SHARED ARTIKEL-DATENBANK (GETEILT FÜR ALLE USER)
   ============================================================================ */
function ArtikelDBView({
  articlesTable, prefs, artSearch, setArtSearch, artCatFilter, setArtCatFilter,
  artBookDate, setArtBookDate, onToggleFavorite, onBookArticle, onEditArticle, onNewArticle
}) {
  const favSet = new Set(prefs.favorites || []);
  const filtered = useMemo(() => {
    const q = (artSearch || '').trim().toLowerCase();
    return Object.values(articlesTable)
      .filter((a) => {
        if (!a || !a.n) return false;
        if (artCatFilter === 'fav' && !favSet.has(a.id)) return false;
        if (artCatFilter !== 'all' && artCatFilter !== 'fav' && a.cat !== artCatFilter) return false;
        if (q && !`${a.n} ${a.p} ${a.gut || ''}`.toLowerCase().includes(q)) return false;
        return true;
      })
      .sort((a, b) => {
        const fa = favSet.has(a.id) ? 1 : 0;
        const fb = favSet.has(b.id) ? 1 : 0;
        if (fa !== fb) return fb - fa;
        return a.n.localeCompare(b.n);
      });
  }, [articlesTable, artSearch, artCatFilter, favSet]);

  return (
    <div className="flex flex-col gap-4">
      <section className="cockpit-card">
        <div className="flex flex-wrap justify-between items-center gap-3 mb-4">
          <div>
            <h2 className="text-lg font-bold">Gemeinsame Artikel- &amp; Rezept-Datenbank</h2>
            <p className="text-xs" style={{ color: 'var(--muted)' }}>
              Shared Table (<code>shared_articles</code>) · Für alle Benutzer sichtbar und sofort buchbar
            </p>
          </div>
          <button type="button" onClick={onNewArticle} className="cockpit-btn primary">
            <PlusCircle className="w-4 h-4" /> Neuer Artikel
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
          <div className="md:col-span-5">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-3" style={{ color: 'var(--muted)' }} />
              <input
                type="text"
                className="cockpit-input !pl-9"
                value={artSearch}
                onChange={(e) => setArtSearch(e.target.value)}
                placeholder="Suche nach Quark, Harzer, Fermentiert, Omega-3…"
              />
            </div>
          </div>
          <div className="md:col-span-5 flex flex-wrap gap-1">
            {[
              { id: 'all', label: 'Alle' },
              { id: 'fav', label: '★ Favoriten' },
              { id: 'saver', label: 'Defizit-Retter' },
              { id: 'upgrade', label: 'Longevity' },
              { id: 'meal', label: 'Mahlzeiten' }
            ].map((c) => (
              <button
                key={c.id}
                type="button"
                onClick={() => setArtCatFilter(c.id)}
                className="cockpit-btn small"
                style={artCatFilter === c.id ? { background: 'var(--accent)', color: 'var(--accent-ink)', borderColor: 'var(--accent)' } : {}}
              >
                {c.label}
              </button>
            ))}
          </div>
          <div className="md:col-span-2">
            <input type="date" className="cockpit-input text-xs" value={artBookDate} onChange={(e) => setArtBookDate(e.target.value)} title="Buchungsdatum" />
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {filtered.map((a) => {
          const isFav = favSet.has(a.id);
          return (
            <article key={a.id} className="cockpit-card flex flex-col justify-between gap-2">
              <div>
                <div className="flex justify-between items-start gap-2">
                  <span className="text-[11px] font-bold uppercase tracking-wider" style={{ color: 'var(--accent)' }}>
                    {a.cat === 'upgrade' ? 'Longevity-Upgrade' : a.cat === 'meal' ? 'Hauptmahlzeit' : 'Defizit-Retter'}
                  </span>
                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => onToggleFavorite(a.id)}
                      className="p-1 text-base cursor-pointer"
                      style={{ color: isFav ? 'var(--kcal)' : 'var(--muted)' }}
                      title="Persönlicher Favorit"
                    >
                      {isFav ? '★' : '☆'}
                    </button>
                    <button type="button" onClick={() => onEditArticle(a)} className="cockpit-btn small !h-7 !px-2">
                      <Edit3 className="w-3 h-3" /> Edit
                    </button>
                  </div>
                </div>
                <h3 className="font-bold text-base mt-0.5">{a.n}</h3>
                <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>{a.p}</p>
                <div className="flex flex-wrap gap-3 font-display font-bold text-sm mt-2 num">
                  <span style={{ color: 'var(--kcal)' }}>{nf0.format(a.k)} kcal</span>
                  <span style={{ color: 'var(--protein)' }}>{nf1.format(a.pr)} g Prot.</span>
                  {num(a.carbs) > 0 && <span>{nf0.format(a.carbs)} g KH</span>}
                  {num(a.fat) > 0 && <span>{nf0.format(a.fat)} g Fett</span>}
                  {num(a.fiber) > 0 && <span style={{ color: 'var(--fiber)' }}>{nf1.format(a.fiber)} g Ball.</span>}
                </div>
              </div>

              <div className="flex justify-between items-center pt-2 border-t mt-2" style={{ borderColor: 'var(--line)' }}>
                <div>
                  {a.gut ? <span className="pill ok text-[11px]">{a.gut}</span> : <span className="text-[11px]" style={{ color: 'var(--muted)' }}>ID: {a.id}</span>}
                </div>
                <div className="flex gap-1.5">
                  <button type="button" onClick={() => onBookArticle(a.id, 0.5)} className="cockpit-btn small">+ ½</button>
                  <button type="button" onClick={() => onBookArticle(a.id, 1)} className="cockpit-btn small primary">+ 1× buchen</button>
                </div>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}

/* ============================================================================
   SUB-VIEW 6: KONTO, PRÄFERENZEN & BENUTZERVERWALTUNG
   ============================================================================ */
function KontoView({ currentUser, cfg, prefs, usersTable, weightsTable, dbUpsert, showToast, onSwitchUser, onLogout, onOpenDBAdmin }) {
  const [displayName, setDisplayName] = useState(currentUser.displayName || '');
  const [theme, setTheme] = useState(prefs.theme || 'system');
  const [curfew, setCurfew] = useState(prefs.curfew ?? 20);
  const [corridor, setCorridor] = useState(prefs.corridor || '0.4-0.7');
  const [newPass, setNewPass] = useState('');

  const [startDate, setStartDate] = useState(cfg.startDate);
  const [startWeight, setStartWeight] = useState(cfg.startWeight);
  const [etappe, setEtappe] = useState(cfg.etappe);
  const [goal, setGoal] = useState(cfg.goal);
  const [kcal, setKcal] = useState(cfg.kcal);
  const [pMin, setPMin] = useState(cfg.proteinMin);
  const [pMax, setPMax] = useState(cfg.proteinMax);
  const [fiber, setFiber] = useState(cfg.fiber);
  const [steps, setSteps] = useState(cfg.steps);

  useEffect(() => {
    setDisplayName(currentUser.displayName || '');
    setTheme(prefs.theme || 'system');
    setCurfew(prefs.curfew ?? 20);
    setCorridor(prefs.corridor || '0.4-0.7');
    setStartDate(cfg.startDate);
    setStartWeight(cfg.startWeight);
    setEtappe(cfg.etappe);
    setGoal(cfg.goal);
    setKcal(cfg.kcal);
    setPMin(cfg.proteinMin);
    setPMax(cfg.proteinMax);
    setFiber(cfg.fiber);
    setSteps(cfg.steps);
  }, [currentUser, cfg, prefs]);

  const savePrefs = async (e) => {
    e.preventDefault();
    const payload = {
      displayName: displayName.trim() || currentUser.username,
      prefs: { ...prefs, theme, curfew: Number(curfew) || 20, corridor }
    };
    if (newPass.trim().length >= 4) {
      payload.passwordHash = await hashPassword(newPass.trim());
    }
    await dbUpsert('app_users', currentUser.username, payload, true);
    setNewPass('');
    showToast('Persönliche Präferenzen gespeichert');
  };

  const saveGoals = async (e) => {
    e.preventDefault();
    const nextCfg = {
      startDate,
      startWeight: Number(startWeight) || 90,
      etappe: Number(etappe) || 85,
      goal: Number(goal) || 80,
      kcal: Number(kcal) || 1800,
      proteinMin: Number(pMin) || 120,
      proteinMax: Number(pMax) || 135,
      fiber: Number(fiber) || 40,
      steps: Number(steps) || 10000
    };
    await dbUpsert('app_users', currentUser.username, { cfg: nextCfg }, true);
    showToast('Persönliche Ziele & Startwerte gespeichert');
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* PRÄFERENZEN JE USER */}
        <section className="cockpit-card">
          <div className="flex justify-between items-baseline mb-3">
            <h2 className="text-lg font-bold">Präferenzen ({currentUser.displayName})</h2>
            <span className="pill ok">@{currentUser.username} · {currentUser.role || 'member'}</span>
          </div>
          <form onSubmit={savePrefs} className="grid grid-cols-2 gap-3">
            <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
              <span>Anzeigename</span>
              <input type="text" className="cockpit-input" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
            </label>
            <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
              <span>Farbschema / Theme</span>
              <select className="cockpit-input" value={theme} onChange={(e) => setTheme(e.target.value)}>
                <option value="system">Systemstandard (Auto)</option>
                <option value="light">Waldgrün Light</option>
                <option value="dark">Waldgrün Dark</option>
              </select>
            </label>
            <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
              <span>Küchenschluss (Uhrzeit)</span>
              <input type="number" min="16" max="23" className="cockpit-input" value={curfew} onChange={(e) => setCurfew(e.target.value)} />
            </label>
            <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
              <span>Abnehm-Korridor (kg/Wo)</span>
              <select className="cockpit-input" value={corridor} onChange={(e) => setCorridor(e.target.value)}>
                <option value="0.3-0.6">Sanft (0,3 – 0,6 kg)</option>
                <option value="0.4-0.7">Standard (0,4 – 0,7 kg)</option>
                <option value="0.5-0.8">Ambitioniert (0,5 – 0,8 kg)</option>
              </select>
            </label>
            <label className="col-span-full flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
              <span>Passwort ändern (optional)</span>
              <input type="password" className="cockpit-input" value={newPass} onChange={(e) => setNewPass(e.target.value)} placeholder="Leer lassen, wenn unverändert" />
            </label>
            <div className="col-span-full flex gap-2 pt-2">
              <button type="submit" className="cockpit-btn primary">Präferenzen speichern</button>
              <button type="button" onClick={onLogout} className="cockpit-btn">Abmelden / Konto wechseln</button>
            </div>
          </form>
        </section>

        {/* ZIELE & GEWICHTS-PARAMETER JE USER */}
        <section className="cockpit-card">
          <div className="flex justify-between items-baseline mb-3">
            <h2 className="text-lg font-bold">Persönliche Ziele &amp; Startwerte</h2>
            <span className="text-xs" style={{ color: 'var(--muted)' }}>Individuell je Benutzer</span>
          </div>
          <form onSubmit={saveGoals} className="grid grid-cols-3 gap-3">
            <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
              <span>Startdatum</span>
              <input type="date" className="cockpit-input" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
            </label>
            <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
              <span>Start (kg)</span>
              <input type="number" step="any" className="cockpit-input" value={startWeight} onChange={(e) => setStartWeight(e.target.value)} />
            </label>
            <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
              <span>Etappe (kg)</span>
              <input type="number" step="any" className="cockpit-input" value={etappe} onChange={(e) => setEtappe(e.target.value)} />
            </label>
            <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
              <span>Ziel (kg)</span>
              <input type="number" step="any" className="cockpit-input" value={goal} onChange={(e) => setGoal(e.target.value)} />
            </label>
            <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
              <span>Kalorien (kcal)</span>
              <input type="number" className="cockpit-input" value={kcal} onChange={(e) => setKcal(e.target.value)} />
            </label>
            <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
              <span>Schritte</span>
              <input type="number" className="cockpit-input" value={steps} onChange={(e) => setSteps(e.target.value)} />
            </label>
            <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
              <span>Prot. Min (g)</span>
              <input type="number" className="cockpit-input" value={pMin} onChange={(e) => setPMin(e.target.value)} />
            </label>
            <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
              <span>Prot. Max (g)</span>
              <input type="number" className="cockpit-input" value={pMax} onChange={(e) => setPMax(e.target.value)} />
            </label>
            <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
              <span>Ballast. (g)</span>
              <input type="number" className="cockpit-input" value={fiber} onChange={(e) => setFiber(e.target.value)} />
            </label>
            <div className="col-span-full pt-2">
              <button type="submit" className="cockpit-btn primary">Ziele speichern</button>
            </div>
          </form>
        </section>
      </div>

      {/* MULTI-USER ÜBERSICHT */}
      <section className="cockpit-card">
        <div className="flex flex-wrap justify-between items-center gap-2 mb-3">
          <div>
            <h2 className="text-lg font-bold">Registrierte Benutzerkonten</h2>
            <p className="text-xs" style={{ color: 'var(--muted)' }}>Jedes Profil besitzt isolierte Gewichts- und Tagesdaten und greift auf dieselbe Artikel-Datenbank zu.</p>
          </div>
          <div className="flex gap-2">
            <button type="button" onClick={onOpenDBAdmin} className="cockpit-btn small">
              <Database className="w-3.5 h-3.5" /> Im DB-Admin inspizieren
            </button>
            <button type="button" onClick={onLogout} className="cockpit-btn small primary">
              <UserPlus className="w-3.5 h-3.5" /> Weiteren User anlegen
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm border-collapse">
            <thead>
              <tr className="border-b text-xs uppercase" style={{ borderColor: 'var(--line)', color: 'var(--muted)' }}>
                <th className="py-2 text-left">Anzeigename</th>
                <th className="py-2 text-left">Username</th>
                <th className="py-2 text-left">Rolle</th>
                <th className="py-2 text-right">Start → Ziel</th>
                <th className="py-2 text-right">Kalorienziel</th>
                <th className="py-2 text-right">Messwerte</th>
                <th className="py-2 text-right">Aktion</th>
              </tr>
            </thead>
            <tbody className="divide-y" style={{ borderColor: 'var(--line)' }}>
              {Object.values(usersTable).map((u) => {
                const isMe = u.username === currentUser.username;
                const wCount = Object.values(weightsTable).filter((w) => w && w.username === u.username).length;
                return (
                  <tr key={u.username}>
                    <td className="py-2.5 font-bold">{u.displayName || u.username}</td>
                    <td className="py-2.5 font-mono-code text-xs" style={{ color: 'var(--muted)' }}>@{u.username}</td>
                    <td className="py-2.5">
                      <span className={`pill ${u.role === 'admin' ? 'warn' : 'na'}`}>{u.role || 'member'}</span>
                    </td>
                    <td className="py-2.5 text-right num">{nf1.format(u.cfg?.startWeight || 90)} → {nf1.format(u.cfg?.goal || 80)} kg</td>
                    <td className="py-2.5 text-right num">{nf0.format(u.cfg?.kcal || 1800)} kcal</td>
                    <td className="py-2.5 text-right num">{wCount}</td>
                    <td className="py-2.5 text-right">
                      {isMe ? (
                        <span className="pill ok">Aktiv</span>
                      ) : (
                        <button type="button" onClick={() => onSwitchUser(u.username)} className="cockpit-btn small">
                          Direkt wechseln
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
}

/* ============================================================================
   SUB-VIEW 7: INTEGRIERTER DATENBANK-ADMINISTRATOR (DB-ADMIN STUDIO)
   ============================================================================ */
function DBAdminStudioView({
  currentUser, syncMode, usersTable, articlesTable, weightsTable, daysTable, auditLog,
  adminActiveTable, setAdminActiveTable, adminSearch, setAdminSearch,
  sqlInput, setSqlInput, sqlResult, setSqlResult, sqlError, setSqlError,
  onEditRecord, onDeleteRecord, onUpsertRecord, onOpenArchModal, showToast
}) {
  const allTables = useMemo(() => ({
    app_users: usersTable,
    shared_articles: articlesTable,
    user_weights: weightsTable,
    user_days: daysTable
  }), [usersTable, articlesTable, weightsTable, daysTable]);

  const activeRows = useMemo(() => {
    const map = allTables[adminActiveTable] || {};
    const q = (adminSearch || '').trim().toLowerCase();
    const list = Object.entries(map).map(([k, v]) => ({ _pk: k, ...v }));
    if (!q) return list;
    return list.filter((r) => JSON.stringify(r).toLowerCase().includes(q));
  }, [allTables, adminActiveTable, adminSearch]);

  const storageSizeKB = useMemo(() => {
    const raw = JSON.stringify(allTables);
    return nf1.format(raw.length / 1024);
  }, [allTables]);

  const runSQL = () => {
    setSqlError(null);
    try {
      const res = executeLiteSQL(sqlInput, allTables);
      setSqlResult(res);
      showToast(`Query ausgeführt: ${res.length} Datensätze gefunden`);
    } catch (err) {
      setSqlError(err.message);
      setSqlResult(null);
    }
  };

  const exportSQLDumpFile = () => {
    const sqlText = generateSQLDump(allTables);
    const blob = new Blob([sqlText], { type: 'application/sql;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cockpit-litedb-dump-${todayStr()}.sql`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    showToast('SQLite / PostgreSQL Dump (.sql) exportiert');
  };

  const exportJSONSnapshot = () => {
    const blob = new Blob([JSON.stringify(allTables, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cockpit-litedb-snapshot-${todayStr()}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    showToast('Kompletter LiteDB JSON-Snapshot exportiert');
  };

  return (
    <div className="flex flex-col gap-4">
      {/* DB-ADMIN HERO HEADER */}
      <section className="rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4" style={{ background: 'var(--hero-bg)', color: 'var(--hero-ink)' }}>
        <div>
          <div className="flex items-center gap-2 text-xs uppercase tracking-wider font-bold" style={{ color: 'var(--hero-fill)' }}>
            <Database className="w-4 h-4" /> LiteDB Engine &amp; Cloud-Sync Administrator
          </div>
          <h2 className="text-2xl font-extrabold mt-1">Datenbank-Administrator Studio</h2>
          <p className="text-xs mt-1" style={{ color: 'var(--hero-muted)' }}>
            Vollständige Kontrolle über alle Tabellen, Indizes, SQL-Abfragen, JSON-Dokumente und GitHub/Vercel-Fullstack-Export.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <button type="button" onClick={exportSQLDumpFile} className="cockpit-btn small">
            <Download className="w-3.5 h-3.5" /> SQL-Dump (.sql)
          </button>
          <button type="button" onClick={exportJSONSnapshot} className="cockpit-btn small">
            <Download className="w-3.5 h-3.5" /> JSON-Snapshot
          </button>
          <button type="button" onClick={onOpenArchModal} className="cockpit-btn small primary">
            <Code className="w-3.5 h-3.5" /> GitHub &amp; Vercel Projekt-Generator
          </button>
        </div>
      </section>

      {/* METRIKEN & TABELLEN-KARTEN */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {Object.entries(DB_SCHEMA).map(([tName, meta]) => {
          const count = Object.keys(allTables[tName] || {}).length;
          const active = adminActiveTable === tName;
          return (
            <button
              key={tName}
              type="button"
              onClick={() => setAdminActiveTable(tName)}
              className="cockpit-card text-left cursor-pointer transition-all flex flex-col justify-between"
              style={active ? { borderColor: 'var(--accent)', boxShadow: '0 0 0 2px var(--accent)' } : {}}
            >
              <div>
                <div className="flex items-center justify-between text-xs font-mono-code font-bold" style={{ color: 'var(--accent)' }}>
                  <span>{tName}</span>
                  <Layers className="w-3.5 h-3.5" />
                </div>
                <div className="font-display font-extrabold text-2xl num mt-1">{count}</div>
              </div>
              <div className="text-[11px] mt-1 truncate" style={{ color: 'var(--muted)' }}>{meta.scope}</div>
            </button>
          );
        })}

        <div className="cockpit-card flex flex-col justify-between">
          <div className="flex items-center justify-between text-xs font-bold uppercase" style={{ color: 'var(--muted)' }}>
            <span>Storage &amp; Engine</span>
            <Server className="w-3.5 h-3.5" style={{ color: 'var(--ok)' }} />
          </div>
          <div className="font-display font-extrabold text-2xl num mt-1">{storageSizeKB} KB</div>
          <div className="text-[11px] mt-1" style={{ color: 'var(--ok)' }}>
            Status: {syncMode === 'cloud' ? 'Firestore Realtime' : 'In-Memory LiteDB'}
          </div>
        </div>
      </div>

      {/* INTERAKTIVE SQL- & FILTER-KONSOLE */}
      <section className="cockpit-card">
        <div className="flex flex-wrap justify-between items-center gap-2 mb-2">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4" style={{ color: 'var(--accent)' }} />
            <h3 className="font-bold text-base">LiteSQL Query Console</h3>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {[
              { label: 'High-Protein Artikel (>25g)', q: 'SELECT id, n, k, pr, cat FROM shared_articles WHERE pr >= 25 ORDER BY pr DESC' },
              { label: 'Alle Benutzer', q: 'SELECT username, displayName, role, createdAt FROM app_users' },
              { label: 'Gewichte (Nadine)', q: 'SELECT date, weight FROM user_weights WHERE username = "nadine" ORDER BY date DESC LIMIT 10' },
              { label: 'Tage > 1700 kcal', q: 'SELECT username, date, kcal, protein, steps FROM user_days WHERE kcal >= 1700 ORDER BY date DESC' }
            ].map((preset, i) => (
              <button
                key={i}
                type="button"
                onClick={() => {
                  setSqlInput(preset.q);
                  setSqlError(null);
                  setSqlResult(executeLiteSQL(preset.q, allTables));
                }}
                className="cockpit-btn small !h-7 !text-[11px]"
              >
                {preset.label}
              </button>
            ))}
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            className="cockpit-input font-mono-code text-xs"
            value={sqlInput}
            onChange={(e) => setSqlInput(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') runSQL(); }}
          />
          <button type="button" onClick={runSQL} className="cockpit-btn primary shrink-0">
            <Play className="w-4 h-4" /> Ausführen
          </button>
        </div>

        {sqlError && (
          <div className="text-xs font-mono-code mt-2 p-2.5 rounded-lg" style={{ background: 'color-mix(in srgb, var(--gap) 14%, var(--surface))', color: 'var(--gap)' }}>
            SQL Fehler: {sqlError}
          </div>
        )}

        {sqlResult && (
          <div className="mt-3 overflow-x-auto border rounded-xl p-2" style={{ borderColor: 'var(--line)', background: 'var(--surface2)' }}>
            <div className="flex justify-between items-center text-xs mb-1.5 px-1" style={{ color: 'var(--muted)' }}>
              <span>Ergebnis: {sqlResult.length} Zeilen</span>
              <button type="button" onClick={() => setSqlResult(null)} className="underline cursor-pointer">Ausblenden</button>
            </div>
            {sqlResult.length === 0 ? (
              <p className="text-xs p-2" style={{ color: 'var(--muted)' }}>Keine Treffer für diese Abfrage.</p>
            ) : (
              <table className="w-full text-xs font-mono-code border-collapse">
                <thead>
                  <tr className="border-b" style={{ borderColor: 'var(--line)', color: 'var(--muted)' }}>
                    {Object.keys(sqlResult[0]).map((col) => (
                      <th key={col} className="py-1.5 px-2 text-left">{col}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y" style={{ borderColor: 'var(--line)' }}>
                  {sqlResult.slice(0, 25).map((row, idx) => (
                    <tr key={idx}>
                      {Object.values(row).map((v, ci) => (
                        <td key={ci} className="py-1.5 px-2 truncate max-w-[220px]">
                          {typeof v === 'object' ? JSON.stringify(v) : String(v ?? 'null')}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        )}
      </section>

      {/* TABELLEN-INSPEKTOR (INKL. INLINE EDIT, INSERT & DELETE) */}
      <section className="cockpit-card">
        <div className="flex flex-wrap justify-between items-center gap-3 mb-3">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold font-mono-code">{adminActiveTable}</h3>
              <span className="pill na text-xs">PK: {DB_SCHEMA[adminActiveTable]?.pk}</span>
            </div>
            <p className="text-xs mt-0.5" style={{ color: 'var(--muted)' }}>
              {DB_SCHEMA[adminActiveTable]?.description}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <input
              type="text"
              className="cockpit-input !h-8 !w-52 text-xs"
              placeholder="Tabelle durchsuchen…"
              value={adminSearch}
              onChange={(e) => setAdminSearch(e.target.value)}
            />
            <button
              type="button"
              onClick={() => {
                const pk = DB_SCHEMA[adminActiveTable]?.pk || 'id';
                const template = {};
                (DB_SCHEMA[adminActiveTable]?.columns || []).forEach((c) => { template[c] = ''; });
                template[pk] = `neu_${Date.now().toString().slice(-4)}`;
                onEditRecord(adminActiveTable, template[pk], template, true);
              }}
              className="cockpit-btn small primary"
            >
              <PlusCircle className="w-3.5 h-3.5" /> Datensatz einfügen
            </button>
          </div>
        </div>

        <div className="overflow-x-auto max-h-[380px] border rounded-xl" style={{ borderColor: 'var(--line)' }}>
          <table className="w-full text-xs font-mono-code border-collapse">
            <thead className="sticky top-0" style={{ background: 'var(--surface2)' }}>
              <tr className="border-b" style={{ borderColor: 'var(--line)', color: 'var(--muted)' }}>
                <th className="py-2 px-3 text-left">Primary Key</th>
                <th className="py-2 px-3 text-left">Datensatz-Vorschau (Spalten / JSON)</th>
                <th className="py-2 px-3 text-right">Aktionen</th>
              </tr>
            </thead>
            <tbody className="divide-y" style={{ borderColor: 'var(--line)' }}>
              {activeRows.map((row) => {
                const pkVal = row._pk;
                const cleanCopy = { ...row };
                delete cleanCopy._pk;
                return (
                  <tr key={pkVal} className="hover:opacity-90">
                    <td className="py-2 px-3 font-bold whitespace-nowrap" style={{ color: 'var(--accent)' }}>
                      {pkVal}
                    </td>
                    <td className="py-2 px-3 truncate max-w-[540px]" style={{ color: 'var(--ink)' }}>
                      {JSON.stringify(cleanCopy)}
                    </td>
                    <td className="py-2 px-3 text-right whitespace-nowrap">
                      <div className="inline-flex gap-1.5">
                        <button
                          type="button"
                          onClick={() => onEditRecord(adminActiveTable, pkVal, cleanCopy, false)}
                          className="cockpit-btn small !h-7 !px-2"
                        >
                          <Edit3 className="w-3 h-3" /> JSON Edit
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            onDeleteRecord(adminActiveTable, pkVal);
                            showToast(`Datensatz ${pkVal} aus ${adminActiveTable} gelöscht`);
                          }}
                          className="cockpit-btn danger small !h-7 !px-2"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      {/* TRANSAKTIONS- & AUDIT-LOG */}
      <section className="cockpit-card">
        <div className="flex justify-between items-center mb-2">
          <h3 className="font-bold text-sm uppercase tracking-wider" style={{ color: 'var(--muted)' }}>
            Echtzeit-Transaktionsprotokoll (Audit-Log)
          </h3>
          <span className="text-xs font-mono-code" style={{ color: 'var(--muted)' }}>{auditLog.length} Events</span>
        </div>
        <div className="max-h-40 overflow-y-auto font-mono-code text-xs divide-y" style={{ borderColor: 'var(--line)' }}>
          {auditLog.map((entry) => (
            <div key={entry.id} className="py-1.5 flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span style={{ color: 'var(--muted)' }}>{entry.ts}</span>
                <span className={`pill text-[10px] ${entry.action === 'DELETE' ? 'gap' : entry.action === 'INSERT' ? 'ok' : 'na'}`}>
                  {entry.action}
                </span>
                <b style={{ color: 'var(--accent)' }}>{entry.table}</b>
                <span>→ {entry.key}</span>
              </div>
              <div className="text-[11px]" style={{ color: 'var(--muted)' }}>
                Actor: <b>{entry.actor}</b>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

/* ============================================================================
   MODALS: ARTIKEL-EDITOR, RAW-JSON-EDITOR & GITHUB/VERCEL PROJEKT-GENERATOR
   ============================================================================ */
function ArticleEditorModal({ initialData, currentUser, onClose, onSave, onDelete }) {
  const [form, setForm] = useState({ ...initialData });
  const setField = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="cockpit-card w-full max-w-lg flex flex-col gap-3 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-bold">{form.id ? 'Artikel bearbeiten (Shared DB)' : 'Neuer Artikel (Shared DB)'}</h2>
          <button type="button" onClick={onClose} className="cockpit-btn small"><X className="w-4 h-4" /></button>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            onSave({
              ...form,
              k: Number(form.k) || 0,
              pr: Number(form.pr) || 0,
              carbs: Number(form.carbs) || 0,
              fat: Number(form.fat) || 0,
              fiber: Number(form.fiber) || 0,
              author: form.author || currentUser.displayName || currentUser.username
            });
          }}
          className="grid grid-cols-2 gap-3"
        >
          <label className="col-span-full flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Name des Artikels / Gerichts</span>
            <input type="text" className="cockpit-input" value={form.n} onChange={(e) => setField('n', e.target.value)} required />
          </label>
          <label className="col-span-full flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Zutaten / Portionsgröße</span>
            <input type="text" className="cockpit-input" value={form.p} onChange={(e) => setField('p', e.target.value)} required />
          </label>
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Kalorien (kcal)</span>
            <input type="number" step="any" className="cockpit-input" value={form.k} onChange={(e) => setField('k', e.target.value)} required />
          </label>
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Protein (g)</span>
            <input type="number" step="any" className="cockpit-input" value={form.pr} onChange={(e) => setField('pr', e.target.value)} required />
          </label>
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Kohlenhydrate (g)</span>
            <input type="number" step="any" className="cockpit-input" value={form.carbs} onChange={(e) => setField('carbs', e.target.value)} />
          </label>
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Fett (g)</span>
            <input type="number" step="any" className="cockpit-input" value={form.fat} onChange={(e) => setField('fat', e.target.value)} />
          </label>
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Ballaststoffe (g)</span>
            <input type="number" step="any" className="cockpit-input" value={form.fiber} onChange={(e) => setField('fiber', e.target.value)} />
          </label>
          <label className="flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Kategorie</span>
            <select className="cockpit-input" value={form.cat} onChange={(e) => setField('cat', e.target.value)}>
              <option value="saver">Defizit-Retter</option>
              <option value="upgrade">Longevity-Upgrade</option>
              <option value="meal">Hauptmahlzeit</option>
            </select>
          </label>
          <label className="col-span-full flex flex-col gap-1 text-xs uppercase font-semibold" style={{ color: 'var(--muted)' }}>
            <span>Longevity / Darm-Badge (optional)</span>
            <input type="text" className="cockpit-input" value={form.gut || ''} onChange={(e) => setField('gut', e.target.value)} placeholder="z. B. Fermentiert, Polyphenole, Omega-3" />
          </label>

          <div className="col-span-full flex justify-between items-center pt-3 border-t" style={{ borderColor: 'var(--line)' }}>
            <button type="submit" className="cockpit-btn primary">Speichern</button>
            {form.id && (
              <button type="button" onClick={() => onDelete(form.id)} className="cockpit-btn danger small">
                <Trash2 className="w-3.5 h-3.5" /> Löschen
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}

function RawRecordModal({ modal, setModal, onSave }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="cockpit-card w-full max-w-xl flex flex-col gap-3">
        <div className="flex justify-between items-center">
          <div>
            <h3 className="font-bold text-base font-mono-code">
              {modal.isNew ? 'INSERT INTO' : 'UPDATE'} {modal.table}
            </h3>
            <span className="text-xs" style={{ color: 'var(--muted)' }}>Primary Key: {modal.id}</span>
          </div>
          <button type="button" onClick={() => setModal(null)} className="cockpit-btn small"><X className="w-4 h-4" /></button>
        </div>

        <textarea
          rows={12}
          className="w-full p-3 rounded-xl border font-mono-code text-xs"
          style={{ background: 'var(--surface2)', borderColor: 'var(--line)', color: 'var(--ink)' }}
          value={modal.jsonText}
          onChange={(e) => setModal({ ...modal, jsonText: e.target.value })}
        />

        <div className="flex justify-end gap-2">
          <button type="button" onClick={() => setModal(null)} className="cockpit-btn">Abbrechen</button>
          <button type="button" onClick={onSave} className="cockpit-btn primary">Transaktion ausführen</button>
        </div>
      </div>
    </div>
  );
}

function VercelArchitectureModal({ dbTables, onClose, showToast }) {
  const [activeFile, setActiveFile] = useState('package.json');

  const files = useMemo(() => ({
    'package.json': JSON.stringify({
      name: 'longevity-abnehm-cockpit',
      private: true,
      version: '2.4.0',
      type: 'module',
      scripts: {
        dev: 'vite',
        build: 'vite build',
        preview: 'vite preview'
      },
      dependencies: {
        react: '^18.3.1',
        'react-dom': '^18.3.1',
        'lucide-react': '^0.454.0',
        firebase: '^11.0.1',
        '@libsql/client': '^0.14.0'
      },
      devDependencies: {
        '@vitejs/plugin-react': '^4.3.3',
        tailwindcss: '^3.4.14',
        vite: '^5.4.10'
      }
    }, null, 2),
    'vercel.json': JSON.stringify({
      version: 2,
      framework: 'vite',
      rewrites: [
        { source: '/api/(.*)', destination: '/api/$1' },
        { source: '/(.*)', destination: '/index.html' }
      ]
    }, null, 2),
    'api/db.js': `// Vercel Serverless API Endpoint (kompatibel mit Turso SQLite / Vercel Postgres)
import { createClient } from '@libsql/client';

const client = createClient({
  url: process.env.TURSO_DATABASE_URL || 'file:local.db',
  authToken: process.env.TURSO_AUTH_TOKEN
});

export default async function handler(req, res) {
  try {
    if (req.method === 'GET') {
      const users = await client.execute('SELECT * FROM app_users');
      const articles = await client.execute('SELECT * FROM shared_articles');
      return res.status(200).json({ users: users.rows, articles: articles.rows });
    }
    if (req.method === 'POST') {
      const { sql, args } = req.body;
      const result = await client.execute({ sql, args: args || [] });
      return res.status(200).json(result);
    }
    return res.status(405).json({ error: 'Method not allowed' });
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
}`,
    'schema.sql': generateSQLDump(dbTables)
  }), [dbTables]);

  const copyCurrent = () => {
    navigator.clipboard?.writeText(files[activeFile]);
    showToast(`${activeFile} in die Zwischenablage kopiert`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="cockpit-card w-full max-w-3xl flex flex-col gap-3 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-lg font-bold">GitHub &amp; Vercel Fullstack Projekt-Generator</h2>
            <p className="text-xs" style={{ color: 'var(--muted)' }}>
              Fertige Projektdateien für Vite + React + Serverless SQLite (Turso / Vercel) inkl. deines aktuellen Datenbestands
            </p>
          </div>
          <button type="button" onClick={onClose} className="cockpit-btn small"><X className="w-4 h-4" /></button>
        </div>

        <div className="flex flex-wrap gap-1.5 border-b pb-2" style={{ borderColor: 'var(--line)' }}>
          {Object.keys(files).map((fname) => (
            <button
              key={fname}
              type="button"
              onClick={() => setActiveFile(fname)}
              className="cockpit-btn small font-mono-code"
              style={activeFile === fname ? { background: 'var(--accent)', color: 'var(--accent-ink)', borderColor: 'var(--accent)' } : {}}
            >
              {fname}
            </button>
          ))}
        </div>

        <div className="relative">
          <button type="button" onClick={copyCurrent} className="cockpit-btn small absolute right-3 top-3">
            <Copy className="w-3.5 h-3.5" /> Kopieren
          </button>
          <pre
            className="p-4 rounded-xl border font-mono-code text-xs overflow-x-auto max-h-[380px]"
            style={{ background: 'var(--surface2)', borderColor: 'var(--line)', color: 'var(--ink)' }}
          >
            {files[activeFile]}
          </pre>
        </div>
      </div>
    </div>
  );
}