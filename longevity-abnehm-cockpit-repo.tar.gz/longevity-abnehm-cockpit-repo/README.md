# Longevity & Abnehm-Cockpit

Vite/React-Projekt, vorbereitet für ein Git-Repository und Deployment auf Vercel.

## Lokal starten

```bash
npm install
npm run dev
```

## Build testen

```bash
npm run build
```

## Deployment auf Vercel

1. Dieses Verzeichnis als Git-Repository initialisieren und zu GitHub/GitLab/Bitbucket pushen.
2. Repository in Vercel importieren.
3. Framework Preset: Vite.
4. Falls Firebase Cloud Sync genutzt wird, die benötigte Konfiguration über sichere Environment Variables bereitstellen und die App entsprechend anbinden.

## Hinweis

Die bestehende App wurde als `src/App.tsx` übernommen. Das Projekt enthält außerdem die minimale Vite-Struktur für einen Git-/Vercel-Workflow.
